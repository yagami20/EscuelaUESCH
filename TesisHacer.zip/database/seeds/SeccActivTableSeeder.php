<?php

use Illuminate\Database\Seeder;
use App\Actividad;
use App\SeccionActiv;

class SeccActivTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $activV = Actividad::where('descripcion','vocales')->first();
        $activA = Actividad::where('descripcion','animales')->first();
        $activF = Actividad::where('descripcion','familia')->first();
        $activN = Actividad::where('descripcion','numeros')->first();

        $act= new SeccionActiv();
        $act->descripcion = "A";
        $act->idActiv = $activV->id;
        $act->save();

        $act= new SeccionActiv();
        $act->descripcion = "E";
        $act->idActiv = $activV->id;
        $act->save();

        $act= new SeccionActiv();
        $act->descripcion = "I";
        $act->idActiv = $activV->id;
        $act->save();

        $act= new SeccionActiv();
        $act->descripcion = "O";
        $act->idActiv = $activV->id;
        $act->save();

        $act= new SeccionActiv();
        $act->descripcion = "U";
        $act->idActiv = $activV->id;
        $act->save();

        //ANIMALES
        $act= new SeccionActiv();
        $act->descripcion = "A";
        $act->idActiv = $activA->id;
        $act->save();

        $act= new SeccionActiv();
        $act->descripcion = "E";
        $act->idActiv = $activA->id;
        $act->save();

        $act= new SeccionActiv();
        $act->descripcion = "I";
        $act->idActiv = $activA->id;
        $act->save();

        $act= new SeccionActiv();
        $act->descripcion = "O";
        $act->idActiv = $activA->id;
        $act->save();

        $act= new SeccionActiv();
        $act->descripcion = "U";
        $act->idActiv = $activA->id;
        $act->save();

        //FAMILIA
        $act= new SeccionActiv();
        $act->descripcion = "A";
        $act->idActiv = $activF->id;
        $act->save();

        $act= new SeccionActiv();
        $act->descripcion = "E";
        $act->idActiv = $activF->id;
        $act->save();

        $act= new SeccionActiv();
        $act->descripcion = "I";
        $act->idActiv = $activF->id;
        $act->save();

        $act= new SeccionActiv();
        $act->descripcion = "O";
        $act->idActiv = $activF->id;
        $act->save();

        $act= new SeccionActiv();
        $act->descripcion = "U";
        $act->idActiv = $activF->id;
        $act->save();

        //NUMEROS

        $act= new SeccionActiv();
        $act->descripcion = "1";
        $act->idActiv = $activN->id;
        $act->save();

        $act= new SeccionActiv();
        $act->descripcion = "2";
        $act->idActiv = $activN->id;
        $act->save();

        $act= new SeccionActiv();
        $act->descripcion = "3";
        $act->idActiv = $activN->id;
        $act->save();

        $act= new SeccionActiv();
        $act->descripcion = "4";
        $act->idActiv = $activN->id;
        $act->save();

        $act= new SeccionActiv();
        $act->descripcion = "5";
        $act->idActiv = $activN->id;
        $act->save();
    }
}
