@extends('layouts.welcome')

@section('content')


<!-- Team Wrap End -->
<div class="row team-wrap">
	<div class="col one-sixth">
          <center>
            <img src="img/flecha.jpg" style="width: 125px; height: 118px" />
          </center>
            <div class="member-name">
               <center>
               <h5 style="color: #f3f3f3">Misión</h5></center>
               {{-- <a href="{{ url('/reproduct') }}" class="small-box-footer">Reprocc <i class="fa fa-arrow-circle-right"></i></a></center> --}}
               {{-- <span class="desc"style="color: #f3f3f3">Miembro área diseño y STEAM</span> --}}
            </div>
            {{-- <ul class="member-social"> --}}
               {{-- <li><a>diana.olmedo@espoch.edu.ec</a></li> --}}
            {{-- </ul> --}}
    </div>

<div class="col one-sixth">
          <center>
            <img src="img/gafas.jpg" style="width: 125px; height: 118px" />
          </center>
            <div class="member-name">
               <center>
               <h5 style="color: #f3f3f3">Visión</h5></center>
            </div>            
</div>
<div class="col one-sixth">
          <center>
            <img src="img/UnidEd.jpg" style="width: 125px; height: 118px" />
          </center>
            <div class="member-name">
               <center>
               <h5 style="color: #f3f3f3">Unidad Educativa</h5></center>
            </div>            
</div>
<div class="col one-sixth">
          <center>
            <img src="img/trophy.png" style="width: 125px; height: 118px" />
          </center>
            <div class="member-name">
               <center>
               <h5 style="color: #f3f3f3">Concursos</h5></center>
            </div>            
</div>
<div class="col one-sixth">
          <center>
            <img src="img/128.jpg" style="width: 125px; height: 118px" />
          </center>
            <div class="member-name">
               <center>
               <h5 style="color: #f3f3f3">Premios</h5></center>
            </div>            
</div>
<div class="col one-sixth">
          <center>
            <img src="img/pngtree.jpg" style="width: 125px; height: 118px" />
          </center>
            <div class="member-name">
               <center>
               <h5 style="color: #f3f3f3">Alumnos</h5></center>
            </div>            
</div>
<div class="col one-sixth">
          <center>
            <img src="img/gestion.jpg" style="width: 125px; height: 118px" />
          </center>
            <div class="member-name">
               <center>
               <h5 style="color: #f3f3f3">Certificados y Cursos</h5></center>
            </div>            
</div>
         

         

         
         

</div> 
@stop