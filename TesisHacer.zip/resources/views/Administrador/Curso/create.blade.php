@extends ('layouts.admin')
@section ('content')
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            
			<h3>Nuevo Curso</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors -> all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif
	</div>
</div>
			{!!Form::open(array('url'=>'UnidadSCH/Curso','method'=>'POST','autocomplete'=>'off','files'=>'true'))!!}
			{{Form::token()}} 

		<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <!-- <form method="POST" action="{{ route('register') }}" aria-label="{{ __('Register') }}"> -->
                        @csrf

                        <div class="form-group row">
                            <label for="idNivel" class="col-md-4 col-form-label text-md-right">{{ __('Nivel') }}</label>

                            <div class="col-md-6">
                                <select name="idNivel" class="form-control">
                                    @foreach($nivel as $tpu)
                                    <option value="{{$tpu->id}}" readonly="readonly" selected>{{$tpu->nombreN}}</option>
                                @endforeach
                                </select>
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <!--  -->
                        <div class="form-group row">
                            <label for="nombreP" class="col-md-4 col-form-label text-md-right">{{ __('Paralelo') }}</label>

                            <div class="col-md-6">
                                <input id="nombreP" type="text" placeholder="A-B-C-..." class="form-control{{ $errors->has('nombreP') ? ' is-invalid' : '' }}" name="nombreP" value="{{ old('nombreP') }}" required autofocus>

                                @if ($errors->has('nombreP'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('nombreP') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            {{-- <label for="nombreA" class="col-md-4 col-form-label text-md-right">{{ __('Año') }}</label> --}}

                            {{-- <div class="col-md-6"> --}}
                                <input id="nombreA" type="hidden" placeholder="A-B-C-..." class="form-control{{ $errors->has('nombreP') ? ' is-invalid' : '' }}" name="nombreA" value="{{ old('nombreP') }}" required autofocus>
{{-- 
                                @if ($errors->has('nombreA'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('nombreA') }}</strong>
                                    </span>
                                @endif
                            </div> --}}
                        </div>
                        <!--  -->
                       <!--  <div class="form-group">
                                            <label for="inputGenero" class="col-sm-offset-2 col-sm-3 control-label">Género</label>
                                            <div class="col-sm-4">
                                              <select>
                                                <option value="Masculino">M</option>
                                                <option value="Femenino" >F</option>
                                              </select>
                                            </div>
                                        </div> -->
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaA" class="col-md-4 col-form-label text-md-right">{{ __('Fecha creación de Curso') }}</label>

                            <div class="col-md-6">
                                <input id="fechaA" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control{{ $errors->has('fechaA') ? ' is-invalid' : '' }}" name="fechaA" value="{{ old('fechaA') }}" required autofocus>

                                @if ($errors->has('fechaA'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('fechaA') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <!--  -->
                        
                        <!--  -->
                        <!--  -->
                        <!--  -->
                        <!--  -->
                        
                        <!--  -->
                        
                        <!--  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    {{ __('Enviar') }}
                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
			
			


			{!!Form::close()!!}

		
@endsection