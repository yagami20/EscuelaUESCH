@extends('layouts.admin')

<link rel="stylesheet" href="{{asset('css/tresColAdm.css')}}">

@section('content')
<div class="container1">
  <div class="sidebar3">
    <br>
    {{-- <div class="box-body box-profile">
    </div> --}}

    <div class="box-body box-profile">
          <center><p><img src="{{asset('img/descarga.jpg')}}" width="150" height="82" /></p></center>

      <video width="100%" height="50%" controls>
        <source src="{{asset('video/ues.mp4')}}" type="video/mp4">
                Your browser does not support the video tag.
      </video>
    </div>
    <!-- end .sidebar1 --></div>
  <div class="content1">
    <center><img src="{{asset('img/título.jpg')}}" width="419" height="115" /></center>
    {{--  --}}<br>
    <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/juego.jpg')}}" width="160" height="100" />

              <center><p>Actividades</p></center>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="{{ url('/UnidadSCH/actividades') }}" class="small-box-footer">Ver <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
    {{--  --}}
    <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/Help.jpg')}}" width="160" height="100" />

              <center><p>Guia de ayuda</p></center>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            {{-- modal --}}
            <a href="" data-target="#modal-delete-{{Auth::user()->id}}" data-toggle="modal" class="small-box-footer">Ver<i class="fa fa-arrow-circle-right"></i></a>
            @include('Administrador.modal')
            {{--  --}}
            {{-- <a href="" class="small-box-footer">Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
          </div>
        </div>
    {{--  --}}
    <CENTER>
    <button>CONTACTOS</button>
    <BUTTON>LEER MAS</BUTTON>
    </CENTER>
    <!-- end .content --></div>
  <div class="sidebar4">
    <h2>CALENDARIO</h2>
    <div class="col one-sixth2">
          <center>
            <iframe src="https://calendar.google.com/calendar/embed?height=600&amp;wkst=1&amp;bgcolor=%23ffffff&amp;ctz=America%2FGuayaquil&amp;src=ZW4uZWMjaG9saWRheUBncm91cC52LmNhbGVuZGFyLmdvb2dsZS5jb20&amp;color=%230B8043" style="border:solid 1px #777" width="240" height="245" frameborder="0" scrolling="no"></iframe>
          </center>
        </div>
  <!-- end .container -->
  </div>

@stop