@extends ('layouts.admin')
@section ('content')
	<div class="container">
		{{-- <center><img style="height: 250px; width: 450px" src="{{asset('404Error.jpg')}}"></center> --}}
		<center><h1>{{$DesT->descTest}}</h1></center>
		<p>Su Nota es: <h2> {{$DesT->notaDes}}</h2></p>
	</div> 
@endsection