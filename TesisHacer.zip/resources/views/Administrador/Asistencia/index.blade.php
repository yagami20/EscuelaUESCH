@extends ('layouts.admin')

    <link rel="stylesheet" href="{{asset('css/botones.css')}}">
@section ('content')
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
    {{-- <h5><a href="{{asset('GestorMSA/Almacen')}}">Almacen</a>/</h5> --}}
		{{-- <h3>Asistencia: <a href="{{URL::action('AdminAsistController@AddEst',auth::user()->id)}}"><button type="button" class="btn btn-outline-success"><i class="fa fa-user-plus"></i> Registrar</button></a></h3><br> --}}
    <h3>Asistencia: <a href="" data-target="#modal-regist-{{auth::user()->id}}" data-toggle="modal"><button type="button" class="btn btn-outline-success"><i class="fa fa-user-plus"></i> Registrar</button></a></h3><br>
    @include('Administrador.Asistencia.modalR')

		<h3>Listado de Asistencia</h3> 
		{{-- @include('Administrador.Asistencia.search') --}}
	</div>
</div>



      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
            </div>
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Apellido</th>
                  
                  <th>Curso</th>
                  
                  <th>Registro</th>                
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  <?php $c = 0;$r=0; ?>
                  @foreach ($userC as $usd)                                    
                  <td>UESCH{{$usd->id}}</td>
                  <td>{{$usd->nomb}}</td>
                  <td>{{$usd->apell}}</td>                  
                  <td>{{$usd->lvl}} {{$usd->cP}}</td>
                  <td>@foreach ($asisR as $usd1)
                  @if ($usd->id==$usd1->id)
                  {{$usd1->fechaAsis}}
                  @endif
                  @endforeach</td>
                  <td>
                    @foreach ($asisR as $usd2)
                    <?php $vI=$asisR[$r]->idAss;
                          $idUreg=$asisR[$r]->id;
                     ?>
                    @if ($usd->id==$usd2->id)<!--registro list -->
                    @if($usd2->eA=='0')<!--est -->
                    <a href="" data-target="#modal-registA-{{$vI}}" data-toggle="modal"><button type="button" class="btn btn-outline-success"><i class="fa fa-user-plus"></i> Asiste</button></a>
                    @else
                    @if($usd2->eA=='1')
                    Registrado
                    @endif
                    @endif<!--fin e -->
                    <?php
                    //if($r==2){$r=0;}
                    //echo "$r"; 
                    ?>
                    @endif<!--fin L-->
                    @endforeach
                    <?php
                    if($userC[$c]->id==$usd->id){
                      $idUf=$userC[$c]->id;
                      //if($r!=3){
                      if($userC[$c]->id==$asisR[$r]->id){
                        $r++;
                      }
                        else{                     
                          ?> 
                    <a href="" data-target="#modal-registF-{{$idUf}}" data-toggle="modal"><button type="button" class="btn btn-outline-danger btn-sm"><i class="fa fa-user-times"></i> Falta</button></a>
                    <?php
                    }  
                      //}
                        
                    }
                    //$c=$c+1;
                    ?>
                    <?php $c=$c+1; ?>
                    {{--  --}}
                    {{--  --}}     
                  </td>                  
                </tr>                
                {{-- @include('Administrador.Asistencia.modal') --}}
                {{-- @include('Administrador.Usuarios.modal2') --}}
                @include('Administrador.Asistencia.modalA')
                @include('Administrador.Asistencia.modalF')
                @endforeach               
              </table>
            </div>
            {{-- {{$userC->render()}} --}}
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>

@endsection