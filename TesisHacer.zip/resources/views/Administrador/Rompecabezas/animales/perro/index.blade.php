@extends('layouts.admin')
<link rel="stylesheet" href="{{asset('css/botones.css')}}">
	<link rel="stylesheet" href="{{asset('css/nPerro.css')}}">
	<script src="{{asset('js/arch.js')}}"></script>
@section('content')
{{-- llenar --}}
<div id='contentS' align='center' class="row">
    <div id="titulo">ROMPECABEZAS</div>
  	<div id='conf'>
			<span>Nro de piezas:</span>
			<select id='piezas'>
        		{{-- <option value='4'>4</option> --}}
				<option value='9'>9</option>
				{{-- <option value='16'>16</option> --}}
				{{-- <option value='25'>25</option> --}}
				{{-- <option value='36'>36</option> --}}
				{{-- <option value='0' disabled>..</option> --}}
				{{-- <option value='0' disabled>..</option> --}}
				{{-- <option value='100'>100</option> --}}
			</select><input type='button' class="btn btn-outline-dark btn-sm" id='barajar' value='Barajar' />
      		<div><p>Pulsa en un cuadro y luego en otro 
      		para intercambiar sus posiciones!!</p></div>
      		<div>
      			<div id="reloj">0 : 00 : 00 : 00</div>
      			<div>
      			<p >Registrar luego de resolver...
      			<a href="{{URL::action('AdminRompController@verObjPerr',$c)}}"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-edit"></i>Registrar Tiempo</button></a></p>
      			</div>
      		</div>
	</div>
</div> 
{{--  --}}
@stop