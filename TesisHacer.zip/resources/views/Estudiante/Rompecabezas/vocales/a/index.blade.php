@extends('layouts.user')
<link rel="stylesheet" href="{{asset('css/botones.css')}}">
	<link rel="stylesheet" href="{{asset('css/vLetrA.css')}}">
	<script src="{{asset('js/arch.js')}}"></script>
	{{-- <link rel="stylesheet" href="{{asset('css/newFont/font-awesome.css')}}"> --}}
	{{-- <link rel="stylesheet" href="{{asset('css/newFont/font-awesome.min.css')}}"> --}}
@section('content')
{{-- llenar --}}
<div id='contentS' align='center' class="row">
    <div id="titulo">ROMPECABEZAS</div>
  	<div id='conf'>
			<span>Nro de piezas:</span>
			<select id='piezas'>
        		<option value='4'>4</option>
				{{-- <option value='9'>9</option> --}}
				{{-- <option value='16'>16</option> --}}
				{{-- <option value='25'>25</option> --}}
				{{-- <option value='36'>36</option> --}}
				{{-- <option value='0' disabled>..</option> --}}
				{{-- <option value='0' disabled>..</option> --}} 
				{{-- <option value='100'>100</option> --}}
			</select>
			<div class="btn-group">
			  <i class="fa fa-bomb" aria-hidden="true"><input type='button' class="btn btn-outline-secondary btn-sm" id='barajar' value='Barajar' /></i>
			  <a href="" data-target="#modal-delete-{{ Auth::user()->id }}" data-toggle="modal"><button type="button" class="btn btn-outline-warning btn-sm"><i class="fa fa-bookmark-o" aria-hidden="true"></i> Pista</button></a>
			  @include('Estudiante.Rompecabezas.vocales.a.modal')
			</div>
			
      		<div><p>Pulsa en un cuadro y luego en otro 
      		para intercambiar sus posiciones!!</p></div>
      		<div>
      			<div id="reloj">0 : 00 : 00 : 00</div>
      			<div>
      			<p >Registrar luego de resolver...
      			<a href="{{URL::action('EstRompController@verObjA',$c)}}"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-edit"></i>Registrar Tiempo</button></a></p>
      			</div>
      		</div>
	</div>
</div>
{{--  --}}
@stop