@extends ('layouts.user')
@section ('content')
	<div class="container">
		{{-- <center><img style="height: 250px; width: 450px" src="{{asset('404Error.jpg')}}"></center> --}}
		<center><h1>Clase Familia Papá</h1></center>
		<center>
		<video width="50%" height="50%" controls>
        <source src="{{asset('video/ayuda.mp4')}}" type="video/mp4">
                Your browser does not support the video tag.
      </video></center>
      <a href="{{ url('/EstudianteSCH/Fam/papa') }}"><button type="button" class="btn btn-outline-secondary btn-sm"><i class="fa fa-share" aria-hidden="true"></i> Siguiente</button></a>
	</div> 
@endsection