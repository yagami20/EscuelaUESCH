@extends ('layouts.user')
<link rel="stylesheet" href="{{asset('css/vFPrihover.css')}}">
<link rel="stylesheet" href="{{asset('css/botones.css')}}">
@section ('content')
<div class="container">
		{{-- <center><img style="height: 250px; width: 450px" src="{{asset('404Error.jpg')}}"></center> --}}
		<table>
			<tr>
				<td>
					<div class="col one-sixth">
          <div id="imagen">
          	<div id="info"></div>
          	<p id="headline">Caracteristicas</p>
          	<p id="info3">La A es la vocal más común en la gran mayoría de lenguas, con notables excepciones como en el caso del francés y del inglés, en los que la más común es la E.</p>
          </div>
    </div>
				</td>
				<td>
					<div class="col one-sixth">
          <div id="imagen2">
          	<div id="infoA"></div>
          	<p id="headline1">Letra A minuscula</p>
          	<p id="info4">La A es la vocal más común en la gran mayoría de lenguas, con notables excepciones como en el caso del francés y del inglés, en los que la más común es la E.</p>
          </div>
    </div>
				</td>
				<td>
					
					<a href="{{ url('EstudianteSCH/ControlActividad/familia/primo/video') }}"><button type="button" class="btn btn-outline-secondary btn-sm"><i class="fa fa-share" aria-hidden="true"></i> Siguiente</button></a>
				</td>
			</tr>
		</table>
	
    
</div> 
@endsection