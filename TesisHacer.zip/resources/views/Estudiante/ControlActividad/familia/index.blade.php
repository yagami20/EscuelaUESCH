@extends('layouts.user')

<link rel="stylesheet" href="{{asset('css/Actividad.css')}}">

@section('content')
<div class="container1">
  <div class="sidebar3">
    <br>
    {{--  --}}
    <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/familia/mama.jpg')}}" width="290" height="100" />

              {{-- <center><p>Vocales</p></center> --}} 
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
              @if(isset($Test3[0])) 
              <a href="{{URL::action('EstVerResActController@verRegMa',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
{{--             <a href="{{ url('/EstudianteSCH/Fam/mama') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
              <a href="{{ url('EstudianteSCH/ControlActividad/familia/mama/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/familia/papa.jpg')}}" width="290" height="100" />

              {{-- <center><p>Vocales</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            
            @if(isset($Test4[0])) 
              <a href="{{URL::action('EstVerResActController@verRegPa',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
{{--             <a href="{{ url('/EstudianteSCH/Fam/papa') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
              <a href="{{ url('EstudianteSCH/ControlActividad/familia/papa/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/familia/herm.jpg')}}" width="290" height="100" />

              {{-- <center><p>Numeros del 1 al 5</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            @if(isset($Test2[0])) 
              <a href="{{URL::action('EstVerResActController@verRegHer',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
{{--             <a href="{{ url('/EstudianteSCH/Fam/hermano') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
              <a href="{{ url('EstudianteSCH/ControlActividad/familia/hermano/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}<br>
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner"> 
              <img src="{{asset('img/familia/abuelo.jpg')}}" width="290" height="100" />

              {{-- <center><p>Integrantes de la familia</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            @if(isset($Test1[0])) 
              <a href="{{URL::action('EstVerResActController@verRegAbu',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
{{--             <a href="{{ url('/EstudianteSCH/Fam/abuelo') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
              <a href="{{ url('EstudianteSCH/ControlActividad/familia/abuelo/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/familia/primo.jpg')}}" width="290" height="100" />

              {{-- <center><p>Animales</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            @if(isset($Test5[0])) 
              <a href="{{URL::action('EstVerResActController@verRegPri',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
{{--             <a href="{{ url('/EstudianteSCH/Fam/primo') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
              <a href="{{ url('EstudianteSCH/ControlActividad/familia/primo/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}
    <!-- end .sidebar1 --></div>

</div>
 
@stop