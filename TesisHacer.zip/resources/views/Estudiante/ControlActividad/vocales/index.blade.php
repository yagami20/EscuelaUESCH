@extends('layouts.user')

<link rel="stylesheet" href="{{asset('css/Actividad.css')}}">

@section('content')
<div class="container1">
  <div class="sidebar3">
    <br>
    {{--  --}}
    <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/vocal/a.jpg')}}" width="290" height="100" />

              {{-- <center><p>Vocales</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i> 
            </div>
            @if(isset($TestA[0])) 
                 
              <a href="{{URL::action('EstVerResActController@verRegA',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
            {{-- <a href="{{ url('/EstudianteSCH/Vocales/A') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
              <a href="{{ url('EstudianteSCH/ControlActividad/vocales/A/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/vocal/e.jpg')}}" width="290" height="100" />

              {{-- <center><p>Vocales</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            @if(isset($TestE[0])) 
                 
              <a href="{{URL::action('EstVerResActController@verRegE',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
            {{-- <a href="{{ url('/EstudianteSCH/Vocales/E') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
              <a href="{{ url('EstudianteSCH/ControlActividad/vocales/E/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/vocal/i.jpg')}}" width="290" height="100" />

              {{-- <center><p>Numeros del 1 al 5</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            @if(isset($TestI[0])) 
                 
              <a href="{{URL::action('EstVerResActController@verRegI',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
            <a href="{{ url('EstudianteSCH/ControlActividad/vocales/I/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}<br>
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/vocal/o.jpg')}}" width="290" height="100" />

              {{-- <center><p>Integrantes de la familia</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            @if(isset($TestO[0])) 
                 
              <a href="{{URL::action('EstVerResActController@verRegO',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
            <a href="{{ url('EstudianteSCH/ControlActividad/vocales/O/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/vocal/u.jpg')}}" width="290" height="100" />

              {{-- <center><p>Animales</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            @if(isset($TestU[0])) 
                 
              <a href="{{URL::action('EstVerResActController@verRegU',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
            <a href="{{ url('EstudianteSCH/ControlActividad/vocales/U/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}
    <!-- end .sidebar1 --></div>
  </div>
 
@stop