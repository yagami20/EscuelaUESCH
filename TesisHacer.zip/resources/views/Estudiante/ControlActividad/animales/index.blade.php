@extends('layouts.user')

<link rel="stylesheet" href="{{asset('css/Actividad.css')}}">

@section('content')
<div class="container1">
  <div class="sidebar3">
    <br>
    {{--  --}}
    <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/animales/gato.jpg')}}" width="290" height="100" />

              {{-- <center><p>Vocales</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
              @if(isset($Test3[0])) 
                 
              <a href="{{URL::action('EstVerResActController@verRegGat',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
{{--             <a href="{{ url('/EstudianteSCH/Anim/Gat') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
              <a href="{{ url('EstudianteSCH/ControlActividad/animales/gato/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/animales/perro.jpg')}}" width="290" height="100" />

              {{-- <center><p>Vocales</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            @if(isset($Test4[0])) 
                 
              <a href="{{URL::action('EstVerResActController@verRegPerr',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
{{--             <a href="{{ url('/EstudianteSCH/Anim/Perr') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
              <a href="{{ url('EstudianteSCH/ControlActividad/animales/perro/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/animales/Gallo.jpg')}}" width="290" height="100" />

              {{-- <center><p>Numeros del 1 al 5</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            @if(isset($Test2[0])) 
                 
              <a href="{{URL::action('EstVerResActController@verRegGall',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
{{--             <a href="{{ url('/EstudianteSCH/Anim/Gall') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
              <a href="{{ url('EstudianteSCH/ControlActividad/animales/gallo/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}<br>
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/animales/vaca.jpg')}}" width="290" height="100" />

              {{-- <center><p>Integrantes de la familia</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            @if(isset($Test5[0])) 
                 
              <a href="{{URL::action('EstVerResActController@verRegVac',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
{{--             <a href="{{ url('/EstudianteSCH/Anim/Vac') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
              <a href="{{ url('EstudianteSCH/ControlActividad/animales/vaca/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/animales/elefante.jpg')}}" width="290" height="100" />

              {{-- <center><p>Animales</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            @if(isset($Test1[0])) 
                 
              <a href="{{URL::action('EstVerResActController@verRegElef',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
{{--             <a href="{{ url('/EstudianteSCH/Anim/Elef') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
              <a href="{{ url('EstudianteSCH/ControlActividad/animales/elef/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}
    <!-- end .sidebar1 --></div>
</div>
 
@stop