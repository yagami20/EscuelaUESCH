@extends('layouts.user')

<link rel="stylesheet" href="{{asset('css/Actividad.css')}}">

@section('content')
<div class="container1">
  <div class="sidebar3">
    <br>
    {{--  --}}
    <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/numero/1.jpg')}}" width="290" height="100" />

              {{-- <center><p>Vocales</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div> 
            {{-- <a href="{{ url('/EstudianteSCH/Num/1') }}" class="small-box-footer">Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
            @if(isset($Test1[0])) 
                 
              <a href="{{URL::action('EstVerResActController@verRegNU',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
            {{-- <a href="{{ url('/EstudianteSCH/Num/1') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>  --}}
              <a href="{{ url('EstudianteSCH/ControlActividad/numeros/1/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/numero/2.jpg')}}" width="290" height="100" />

              {{-- <center><p>Vocales</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            {{-- <a href="{{ url('/EstudianteSCH/Num/2') }}" class="small-box-footer">Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
            @if(isset($Test2[0])) 
                 
              <a href="{{URL::action('EstVerResActController@verRegND',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
            {{-- <a href="{{ url('/EstudianteSCH/Num/2') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
              <a href="{{ url('EstudianteSCH/ControlActividad/numeros/2/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/numero/3.jpg')}}" width="290" height="100" />

              {{-- <center><p>Numeros del 1 al 5</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            {{-- <a href="{{ url('/EstudianteSCH/Num/3') }}" class="small-box-footer">Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
            @if(isset($Test3[0])) 
                 
              <a href="{{URL::action('EstVerResActController@verRegNT',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
            {{-- <a href="{{ url('/EstudianteSCH/Num/3') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
              <a href="{{ url('EstudianteSCH/ControlActividad/numeros/3/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}<br>
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/numero/4.jpg')}}" width="290" height="100" />

              {{-- <center><p>Integrantes de la familia</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            {{-- <a href="{{ url('/EstudianteSCH/Num/4') }}" class="small-box-footer">Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
            @if(isset($Test4[0])) 
                 
              <a href="{{URL::action('EstVerResActController@verRegNC',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
{{--             <a href="{{ url('/EstudianteSCH/Num/4') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
              <a href="{{ url('EstudianteSCH/ControlActividad/numeros/4/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="{{asset('img/numero/5.jpg')}}" width="290" height="100" />

              {{-- <center><p>Animales</p></center> --}}
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            {{-- <a href="{{ url('/EstudianteSCH/Num/5') }}" class="small-box-footer">Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
            @if(isset($Test5[0])) 
                 
              <a href="{{URL::action('EstVerResActController@verRegNCC',auth::user()->id)}}" class="small-box-footer">
              <img src="{{asset('img/icon.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @else 
{{--             <a href="{{ url('/EstudianteSCH/Num/5') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a> --}}
              <a href="{{ url('EstudianteSCH/ControlActividad/numeros/5/info') }}" class="small-box-footer">
              <img src="{{asset('img/err.png')}}" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            @endif
          </div>
        </div>
        {{--  --}}
    <!-- end .sidebar1 --></div>
  {{-- <div class="content1">
    <h2>Información</h2>
    <p><textarea name="descripcion" cols="40" rows="5" placeholder="Write something here..." readonly></textarea></p>
    <h2>Descripción</h2>
    <p><textarea name="descrion" cols="40" rows="10" placeholder="Write something here..." readonly></textarea></p>
   --}}  
    {{--  --}}
    <!-- end .content -->
  {{-- </div> --}}
  {{-- </div> --}}
 
@stop