@extends ('layouts.user')

    <link rel="stylesheet" href="{{asset('css/botones.css')}}">
@section ('content')
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
    {{-- <h5><a href="{{asset('GestorMSA/Almacen')}}">Almacen</a>/</h5> --}}
		<h3>Test: </h3><br>

		<h3>{{$Test[0]->desTest}}</h3> 
		{{-- @include('Administrador.Usuarios.search') --}}
	</div>
</div>



      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <!-- <h3 class="box-title">Listado de materiales</h3> -->
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              {{-- rellenado --}}
            {!!Form::open(array('url'=>'EstudianteSCH/Activ/Regist','method'=>'POST','autocomplete'=>'off','files'=>'true'))!!}
            {{Form::token()}}
                        @csrf
              {{--  --}}
              <?php $c=0;?>
              @foreach ($Preg as $usd)
              <p><font size="2" face="Arial, Helvetica, sans-serif">
              	<strong>{{$usd->desPreg}}?</strong></font></p>
              	@foreach($Resp as $usdR)
              	@if($usd->id==$usdR->idP)
              	<p><font  size="2" face="Arial, Helvetica, sans-serif"> 
    			       <input type="radio" name="p<?php echo $c;?>" value="{{$usdR->id}}">
    			       <font ><img src="{{asset('/img/Resp/'.$usdR->descripR)}}" style="width: 125px; height: 140px" class="user-image" alt="User Image"></font></font></p>
    			       <?php $c++; ?>
              	@endif
              	@endforeach
              @endforeach
              {{--  --}}
              <input type="hidden" name="tam" value="{{$c}}">
              <input type="hidden" name="idTest" value="{{$Test[0]->id}}">
              {{-- <input type="hidden" name="nombUsDes" value=""> --}}
              <input type="hidden" name="descTest" value="{{$Test[0]->desTest}}">
              	<div>
                            {{-- <div class="col-xs-12"> --}}
{{--                                 <button type="submit" class="btn btn-primary">
                                    {{ __('Registrar') }}
                                </button> --}}
            <input name="agregar" type="submit" class="btn btn-primary" id="agregar" value="Registrar"
            <?php if(isset($Resp[0])){echo 'enabled';} else{ echo 'disabled'; }?>
            >
                            {{-- </div> --}}
                </div>
              {!!Form::close()!!}
              {{--  --}}
            </div>
            {{-- {{$usuario->render()}} --}}
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>

@endsection