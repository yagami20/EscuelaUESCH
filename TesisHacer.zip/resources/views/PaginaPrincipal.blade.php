@extends('layouts.welcome')

@section('content')
<div class="row">
        <center>
         <div class="col full"><h3 style="color: #f1f1f1">UNIDAD EDUCATIVA DE SORDOS DE CHIMBORAZO</h3></div>
        </center>
        <div class="col full">
            {{--  --}}
        </div>
</div>

      <!-- Team Wrap End -->
<div class="row team-wrap">
  <div class="col one-sixth">
    <center>
      <iframe width="240" height="245" src="https://www.youtube.com/embed/pauLiXco_-8" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </center>
  </div>
      <div class="col one-sixth1">
        <center>
          <img src="img/descarga.jpg" style="width: 450px; height: 380px" class="img-thumbnail">
        </center>
      <div class="member-name">
        <center>
          <button>Contactos</button>
          <button>Leer mas</button>
        </center>
      </div>
      </div>

         
        <div class="col one-sixth2">
          <center>
            <span class="desc" style="color: #f3f3f3">Calendario</span>
            <iframe src="https://calendar.google.com/calendar/embed?height=600&amp;wkst=1&amp;bgcolor=%23ffffff&amp;ctz=America%2FGuayaquil&amp;src=ZW4uZWMjaG9saWRheUBncm91cC52LmNhbGVuZGFyLmdvb2dsZS5jb20&amp;color=%230B8043" style="border:solid 1px #777" width="240" height="245" frameborder="0" scrolling="no"></iframe>
          </center>
              <div class="member-name">
                <span class="desc" style="color: #f3f3f3">Noticias</span>
                 <noscript><a href="https://www.expansion.com" title="noticias de economía">Expansion.com</a></noscript><script type="text/javascript" src="https://www.expansion.com/widgets/launcher.html?c=tamano&w=250&h=250&news=Transporte%20y%20Turismo" id="wm001001304"></script>
              </div>
              <div class="member-name">
                <span class="desc" style="color: #f3f3f3">Ubicanos</span>
                  <iframe src="https://www.google.com/maps/embed?pb=!1m23!1m12!1m3!1d15952.496195543601!2d-78.66169378352049!3d-1.6698133818269345!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m8!3e6!4m0!4m5!1s0x91d3a8316b8ae81f%3A0x944928ad28d6d8ef!2sInstituto%20de%20Sordos%20de%20Chimborazo%2C%20Argentinos%2C%20Riobamba!3m2!1d-1.6756961!2d-78.6416758!5e0!3m2!1ses-419!2sec!4v1600702602830!5m2!1ses-419!2sec" width="240" height="245" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
              </div>
        </div>

</div> 
@stop