@extends('layouts.welcome')

@section('content')
{{-- <div class="row"> --}}
        {{-- <center> --}}
         {{-- <div class="col full"><h3 style="color: #f1f1f1">DOCENTES</h3></div> --}}
        {{-- </center> --}}
        {{-- <div class="col full"> --}}
            {{--  --}}
        {{-- </div> --}}
{{-- </div> --}}
{{-- <section id="nosotros" style="background: #0f8488"> --}}
	<div class="row">
         <div class="col full"><h3 style="color: lightgray">Equipo de trabajo.</h3></div>
      </div>

      <!-- Team Wrap End -->
      <div class="row team-wrap">

         <div class="col one-sixth">
          <center>
            <img src="img/profesora.jpg" alt=""/>
          </center>
            <div class="member-name">
               <h5 style="color: #f3f3f3">Lic. Susana Romero</h5>
               <span class="desc" style="color: #f3f3f3">Rectora de la Unidad Educativa</span>
            </div>

          </div>

         <div class="col one-sixth">
          <center>
            <img src="img/profesora.jpg" alt="" height="166px" />
          </center>
            <div class="member-name">
               <h5 style="color: #f3f3f3">Lic. Olga Monteros</h5>
               <span class="desc"style="color: #f3f3f3">Docente Inicial II</span>
            </div>

            </div>

         <div class="col one-sixth">
          <center>
            <img src="img/profesora.jpg" alt=""/>
          </center>
            <div class="member-name">
               <h5 style="color: #f3f3f3">Lic. Susana Romero</h5>
               <span class="desc" style="color: #f3f3f3">Docente de segundo de Basica</span>
            </div>

          </div>

         
         <div class="col one-sixth">
          <center>
            <img src="img/profesora.jpg" alt=""/>
          </center>
            <div class="member-name">
               <h5 style="color: #f3f3f3">Lic. Susana Romero</h5>
               <span class="desc" style="color: #f3f3f3">Docente de segundo de Basica</span>
            </div>

          </div>
      </div> <!-- Team Wrap End -->


  {{-- </section> --}}

@stop