@extends('layouts.welcome')

@section('content')


<!-- Team Wrap End -->
<div class="row team-wrap">
         
	<h1>Tekken</h1>
    <video width="100%" height="50%" controls>
        <source src="{{asset('../../../../../video/1.mp4')}}" type="video/mp4">
                Your browser does not support the video tag.
    </video>

    <h1>R2</h1>
    <video width="100%" height="50%" controls>
        <source src="{{asset('video/25.mp4')}}" type="video/mp4">
                Your browser does not support the video tag.
    </video>

    <h1>s1</h1>
<video width="100%" height="50%" controls>
        <source src="{{asset('video/2.mp4')}}" type="video/mp4">
                Your browser does not support the video tag.
    </video>

    <h1>s2</h1>
<video width="100%" height="50%" controls>
        <source src="{{asset('video/3.mp4')}}" type="video/mp4">
                Your browser does not support the video tag.
    </video>

    <h1>s3</h1>
<video width="100%" height="50%" controls>
        <source src="{{asset('video/4.mp4')}}" type="video/mp4">
                Your browser does not support the video tag.
    </video>

    <h1>File Open Video</h1>
<video width="100%" height="50%" controls>
        <source src="{{asset('video/5.mp4')}}" type="video/mp4">
                Your browser does not support the video tag.
    </video>

    <h1>web</h1>
    <iframe src="https://streamtape.com/e/ydYwGX0z7aiwaq/" width="100%" height="50%" allowfullscreen allowtransparency allow="autoplay" scrolling="no" frameborder="0"></iframe>

    <h1>RRH1</h1>
<video width="100%" height="50%" controls>
        <source src="{{asset('video/rd/r1.mp4')}}" type="video/mp4">
                Your browser does not support the video tag.
    </video>

    <h1>RRH2</h1>
<video width="100%" height="50%" controls>
        <source src="{{asset('video/rd/r2.mp4')}}" type="video/mp4">
                Your browser does not support the video tag.
    </video>
         
         

</div> 
@stop