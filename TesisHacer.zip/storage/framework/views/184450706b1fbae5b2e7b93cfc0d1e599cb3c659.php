<link rel="stylesheet" href="<?php echo e(asset('css/vN4.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
<?php $__env->startSection('content'); ?>
<div class="container">
		
		<table>
			<tr>
				<td>
					<div class="col one-sixth">
          <div id="imagen">
          	<div id="info"></div>
          	<p id="headline">Caracteristicas</p>
          	<p id="info3">La A es la vocal más común en la gran mayoría de lenguas, con notables excepciones como en el caso del francés y del inglés, en los que la más común es la E.</p>
          </div>
    </div>
				</td>
				<td>
					<div class="col one-sixth">
          <div id="imagen2">
          	<div id="infoA"></div>
          	<p id="headline1">Letra A minuscula</p>
          	<p id="info4">La A es la vocal más común en la gran mayoría de lenguas, con notables excepciones como en el caso del francés y del inglés, en los que la más común es la E.</p>
          </div>
    </div>
				</td>
				<td>
					<a href="<?php echo e(url('EstudianteSCH/ControlActividad/numeros/4/video')); ?>"><button type="button" class="btn btn-outline-secondary btn-sm"><i class="fa fa-share" aria-hidden="true"></i> Siguiente</button></a>
				</td>
			</tr>
		</table>
	
    
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>