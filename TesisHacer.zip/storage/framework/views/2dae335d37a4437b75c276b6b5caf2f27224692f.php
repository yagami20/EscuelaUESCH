    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
<?php $__env->startSection('content'); ?>
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
    
    <h5><a href="<?php echo e(asset('UnidadSCH/Test')); ?>"><?php echo e($test->desTest); ?></a>>
            </h5>
		<h3>Pregunta: 
      
      
      <a href="" data-target="#modal-registA-<?php echo e($valor); ?>" data-toggle="modal"><button type="button" class="btn btn-outline-success"><i class="fa fa-user-plus"></i> Registrar</button></a>
    </h3><br>
    <?php echo $__env->make('Administrador.Test.Pregunt.modalR', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<h3>Listado de Preguntas</h3> 
		
	</div>
</div>



      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <!-- <h3 class="box-title">Listado de materiales</h3> -->
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  
                  <th>Nombre</th>               
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                	<?php $__currentLoopData = $preg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                  
                  <td><?php echo e($usd->desPreg); ?></td>                  
                  <td>
                  	
                    <a href="<?php echo e(URL::action('AdminPregController@verList',$usd->id)); ?>"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-user-plus"></i>Respuesta Agg.</button></a>
                    <a href="<?php echo e(URL::action('AdminPregController@edit',$usd->id)); ?>"><button type="button" class="btn btn-outline-info btn-sm"><i class="fa fa-edit"></i> Editar</button></a>
                    <a href="" data-target="#modal-delete-<?php echo e($usd->id); ?>" data-toggle="modal"><button type="button" class="btn btn-outline-danger btn-sm"><i class="fa fa-user-times"></i> Eliminar</button></a>
                    
                  </td>
                </tr>
                
                <?php echo $__env->make('Administrador.Test.Pregunt.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>               
              </table>
            </div>
            
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>