<div class="modal fade modal-slide-in-right" aria-hidden="true" role="dialog" tabindex="-1" id="modal-registA-<?php echo e($valor); ?>">
<?php echo Form::open(array('url'=>'UnidadSCH/Test/Preg','method'=>'POST','autocomplete'=>'off','files'=>'true')); ?>

            <?php echo e(Form::token()); ?>

                        <?php echo csrf_field(); ?>
<div class="modal-dialog">
	<div class="modal-content">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-Label="Close">
			<span aria-hidden="true">X</span>
			
		</button>
		<h4 class="modal-title">Registrar Pregunta</h4>
	</div>
	<div class="modal-body">
		
		
		                <div class="form-group row">
                            <label for="desTest" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Test')); ?></label>

                            <div class="col-md-6">

                                <input id="desTest" type="text" placeholder="0123456789" class="form-control<?php echo e($errors->has('desTest') ? ' is-invalid' : ''); ?>" name="desTest" value="<?php echo e($test->desTest); ?>" readonly>
                                <input type="hidden" name="idTest" value="<?php echo e($test->id); ?>">
                            </div>
                        </div>                        <!--nuevos dtos  -->
                        <!--  -->
                        <div class="form-group row">
                            <label for="desPreg" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                            <div class="col-md-6"> 
                                <input id="desPreg" type="text" class="form-control<?php echo e($errors->has('desPreg') ? ' is-invalid' : ''); ?>" name="desPreg" value="<?php echo e(old('desPreg')); ?>" required autofocus>

                                <?php if($errors->has('desPreg')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('desPreg')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!--  -->

                        
		
	</div>
	<div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
		<button type="submit" class="btn btn-primary">Confirmar</button>
	</div>
	</div>
</div>
<?php echo e(Form::Close()); ?>	

</div>