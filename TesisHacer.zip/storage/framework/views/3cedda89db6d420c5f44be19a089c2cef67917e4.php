<link rel="stylesheet" href="<?php echo e(asset('css/Actividad.css')); ?>">

<?php $__env->startSection('content'); ?>
<div class="container1">
  <div class="sidebar3">
    <br>
    
    <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="<?php echo e(asset('img/numero/1.jpg')); ?>" width="290" height="100" />

              
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div> 
            
            <?php if(isset($Test1[0])): ?> 
                 
              <a href="<?php echo e(URL::action('EstVerResActController@verRegNU',auth::user()->id)); ?>" class="small-box-footer">
              <img src="<?php echo e(asset('img/icon.png')); ?>" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            <?php else: ?> 
            
              <a href="<?php echo e(url('EstudianteSCH/ControlActividad/numeros/1/info')); ?>" class="small-box-footer">
              <img src="<?php echo e(asset('img/err.png')); ?>" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            <?php endif; ?>
          </div>
        </div>
        
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="<?php echo e(asset('img/numero/2.jpg')); ?>" width="290" height="100" />

              
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            
            <?php if(isset($Test2[0])): ?> 
                 
              <a href="<?php echo e(URL::action('EstVerResActController@verRegND',auth::user()->id)); ?>" class="small-box-footer">
              <img src="<?php echo e(asset('img/icon.png')); ?>" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            <?php else: ?> 
            
              <a href="<?php echo e(url('EstudianteSCH/ControlActividad/numeros/2/info')); ?>" class="small-box-footer">
              <img src="<?php echo e(asset('img/err.png')); ?>" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            <?php endif; ?>
          </div>
        </div>
        
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="<?php echo e(asset('img/numero/3.jpg')); ?>" width="290" height="100" />

              
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            
            <?php if(isset($Test3[0])): ?> 
                 
              <a href="<?php echo e(URL::action('EstVerResActController@verRegNT',auth::user()->id)); ?>" class="small-box-footer">
              <img src="<?php echo e(asset('img/icon.png')); ?>" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            <?php else: ?> 
            
              <a href="<?php echo e(url('EstudianteSCH/ControlActividad/numeros/3/info')); ?>" class="small-box-footer">
              <img src="<?php echo e(asset('img/err.png')); ?>" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            <?php endif; ?>
          </div>
        </div>
        <br>
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="<?php echo e(asset('img/numero/4.jpg')); ?>" width="290" height="100" />

              
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            
            <?php if(isset($Test4[0])): ?> 
                 
              <a href="<?php echo e(URL::action('EstVerResActController@verRegNC',auth::user()->id)); ?>" class="small-box-footer">
              <img src="<?php echo e(asset('img/icon.png')); ?>" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            <?php else: ?> 

              <a href="<?php echo e(url('EstudianteSCH/ControlActividad/numeros/4/info')); ?>" class="small-box-footer">
              <img src="<?php echo e(asset('img/err.png')); ?>" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            <?php endif; ?>
          </div>
        </div>
        
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="<?php echo e(asset('img/numero/5.jpg')); ?>" width="290" height="100" />

              
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            
            <?php if(isset($Test5[0])): ?> 
                 
              <a href="<?php echo e(URL::action('EstVerResActController@verRegNCC',auth::user()->id)); ?>" class="small-box-footer">
              <img src="<?php echo e(asset('img/icon.png')); ?>" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            <?php else: ?> 

              <a href="<?php echo e(url('EstudianteSCH/ControlActividad/numeros/5/info')); ?>" class="small-box-footer">
              <img src="<?php echo e(asset('img/err.png')); ?>" width="15" height="15" />
              Ver <i class="fa fa-arrow-circle-right"></i></a>
            <?php endif; ?>
          </div>
        </div>
        
    <!-- end .sidebar1 --></div>
    
    
    <!-- end .content -->
  
  
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>