<link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/menu.css">
    <link rel="stylesheet" href="css/layout.css">
    <link rel="stylesheet" href="css/proyectos.css">

   <!-- Favicons
    ================================================== -->
    <link rel="shortcut icon" href="img/images.jpg" >
    
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
   <script>window.jQuery || document.write('<script src="js/jquery-1.10.2.min.js"><\/script>')</script>
   <script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
   <script src="js/app.js"></script>
   <script src="js/scrollspy.js"></script>
   <script src="js/jquery.flexslider.js"></script>
   <script src="js/jquery.reveal.js"></script>
   <script src="http://maps.google.com/maps/api/js?sensor=true" type="text/javascript"></script>
   <script src="js/gmaps.js"></script>
   <script src="js/init.js"></script>
   <script src="js/smoothscrolling.js"></script>
    

<?php $__env->startSection('content'); ?>
<div class="row">
        <center>
         <div class="col full"><h3 style="color: #f1f1f1">Inicial II</h3></div>
        </center>
        <div class="col full">
            
        </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>