<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Curso: <?php echo e($preg->desPreg); ?></h3>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
				<?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
	</div>
</div>

	
			

<form method="POST" action="/DocenteSCH/Test/Preg/<?php echo e($preg->id); ?>" enctype="multipart/form-data">
	<?php echo method_field('PUT'); ?>
	<?php echo csrf_field(); ?>
	<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <!-- <form method="POST" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>"> -->
                       

                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="desTest" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Test')); ?></label>

                            <div class="col-md-6">

                                <input id="desTest" type="text" placeholder="0123456789" class="form-control<?php echo e($errors->has('desTest') ? ' is-invalid' : ''); ?>" name="desTest" value="<?php echo e($test->desTest); ?>" readonly>
                                <input type="hidden" name="idTest" value="<?php echo e($test->id); ?>">
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="desPreg" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Pregunta')); ?></label>

                            <div class="col-md-6">
                                <input id="desPreg" type="text" placeholder="Nombre Apellido" class="form-control<?php echo e($errors->has('desPreg') ? ' is-invalid' : ''); ?>" name="desPreg" value="<?php echo e($preg->desPreg); ?>" required autofocus>

                                <?php if($errors->has('desPreg')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('desPreg')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <!--  -->
                        <!--  -->
                        
                        <!--  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    <?php echo e(__('Enviar')); ?>

                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
</form>		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.docente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>