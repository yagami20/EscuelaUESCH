    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
<?php $__env->startSection('content'); ?>
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
    
		<h3>Reporte General Actividades: 
    <a href="<?php echo e(URL::action('pdfRepAsisController@genListA',Auth::user()->id)); ?>"><button type="button" class="btn btn-outline-success"><i class="fa fa-user-plus"></i>Generar</button></a>
    
    

		
		
    <h3>Listado de Actividades</h3> 
	</div>
</div>



      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Numero de Alumnos</th>
                  <th>Tiempo</th>
                  
                  
                  
                  
                  
                  
                  
                </tr>
                <tr>
                  <?php $__currentLoopData = $asisR; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                  
                  
                  
                  
                  
                  
                  <td><?php echo e($usd->n_Us); ?></td>
                  <td><?php echo e($usd->tiempo); ?></td>
                  
                    
                    
                  
                </tr>
                
                
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
              </table>
            </div>
            
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>