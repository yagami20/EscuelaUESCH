<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            
			<h3>Nuevo Test</h3>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
				<?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
	</div>
</div>
			

		<div class="container">
            
    <div class="card-body">
                    
    <?php echo Form::open(array('url'=>'UnidadSCH/Test','method'=>'POST','autocomplete'=>'off','files'=>'true')); ?>

            <?php echo e(Form::token()); ?>

                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="desTest" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                            <div class="col-md-6"> 
                                <input id="desTest" type="text" class="form-control<?php echo e($errors->has('desTest') ? ' is-invalid' : ''); ?>" name="desTest" value="<?php echo e(old('desTest')); ?>" required autofocus>

                                <?php if($errors->has('desTest')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('desTest')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        
                        <div class="form-group row">
                            <label for="genero" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Seleccion Genero Actividad')); ?></label>

                            <div class="col-md-6">
                                <!-- <div class="col-sm-4"> -->
                                <select name="tipoTest" id="gActivid" class="form-control">
                                    <?php $__currentLoopData = $act; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tps->id); ?>">
                                                    <?php echo e($tps->descripcion); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </select>
                                            <!-- </div> -->

                                <?php if($errors->has('genero')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('genero')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!-- -->
                        <div class="form-group row">
                            <label for="genero" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Seleccion Actividad')); ?></label>

                            <div class="col-md-6">
                                <!-- <div class="col-sm-4"> -->
                                            <select name="SA" id="selAct" class="form-control">
                                                
                                            </select>
                                            <!-- </div> -->

                                <?php if($errors->has('genero')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('genero')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    
                    <?php echo Form::close(); ?>

                </div>
        </div>
			
			


			

<?php $__env->startPush('scripts'); ?>
<script>

var selGA={
_limpiar: function(){
// $("#selAct option:selected").val("");
// $('#selAct').append("");
$("#selAct option:selected").val("");
// $("#selAct option:selected").text("");
$("#selAct").text("");
},

_agregar: function(){
    gActic=$("#gActivid option:selected").val();
    if(gActic == 1){
        selGA._limpiar();
        var fila1='<option value="1">Elefante</option><option value="2">Gallo</option><option value="3">Gato</option><option value="4">Perro</option><option value="5">Vaca</option>';
        $('#selAct').append(fila1);
        // $('#selAct').appendChild(fila1);
            // document.body.appendChild(fila1); 
    }
    else{
        if(gActic == 2){
        selGA._limpiar();
        var fila2='<option value="6">Abuelo</option><option value="7">Hermano</option><option value="8">Mama</option><option value="9">Papa</option><option value="10">Primo</option>';
        $('#selAct').append(fila2);
        }
        else{
        if(gActic == 3){
        selGA._limpiar();
        var fila3='<option value="11">1</option><option value="12">2</option><option value="13">3</option><option value="14">4</option><option value="15">5</option>';
        $('#selAct').append(fila3);
        }
        else{
            selGA._limpiar();
        var fila4='<option value="16">A</option><option value="17">E</option><option value="18">I</option><option value="19">O</option><option value="20">U</option>';
        $('#selAct').append(fila4);
        }   
        }
    }  
},

_get: function(id){
        return document.getElementById(id);
    }

};



window.onload = function(){
    // var cr=agregar();
    selGA._get("gActivid").onchange = function(){
        selGA._agregar();
    }

    selGA._get("gActivid").onclick = function(){
      selGA._agregar();
    }   
}

</script>
<?php $__env->stopPush(); ?>

		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>