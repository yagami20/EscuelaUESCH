<link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/nPerro.css')); ?>">
	<script src="<?php echo e(asset('js/arch.js')); ?>"></script>
<?php $__env->startSection('content'); ?>

<div id='contentS' align='center' class="row">
    <div id="titulo">ROMPECABEZAS</div>
  	<div id='conf'>
			<span>Nro de piezas:</span>
			<select id='piezas'>
        		
				<option value='9'>9</option>
				
				
				
				
				
				
			</select>
			<div class="btn-group">
			  <i class="fa fa-bomb" aria-hidden="true"><input type='button' class="btn btn-outline-secondary btn-sm" id='barajar' value='Barajar' /></i>
			  <a href="" data-target="#modal-delete-<?php echo e(Auth::user()->id); ?>" data-toggle="modal"><button type="button" class="btn btn-outline-warning btn-sm"><i class="fa fa-bookmark-o" aria-hidden="true"></i> Pista</button></a>
			  <?php echo $__env->make('Estudiante.Rompecabezas.animales.perro.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
			<div><p>Pulsa en un cuadro y luego en otro 
      		para intercambiar sus posiciones!!</p></div>
      		<div>
      			<div id="reloj">0 : 00 : 00 : 00</div>
      			<div>
      			<p >Registrar luego de resolver...
      			<a href="<?php echo e(URL::action('EstRompController@verObjPerr',$c)); ?>"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-edit"></i>Registrar Tiempo</button></a></p>
      			</div>
      		</div>
	</div>
</div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>