<link rel="stylesheet" href="<?php echo e(asset('css/Actividad.css')); ?>">

<?php $__env->startSection('content'); ?>
<div class="container1">
  <div class="sidebar3">
    <br>
    
    <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="<?php echo e(asset('img/animales/gato.jpg')); ?>" width="290" height="100" />

              
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="<?php echo e(url('/UnidadSCH/Anim/Gat')); ?>" class="small-box-footer">Ver <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="<?php echo e(asset('img/animales/perro.jpg')); ?>" width="290" height="100" />

              
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="<?php echo e(url('/UnidadSCH/Anim/Perr')); ?>" class="small-box-footer">Ver <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="<?php echo e(asset('img/animales/Gallo.jpg')); ?>" width="290" height="100" />

              
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="<?php echo e(url('/UnidadSCH/Anim/Gall')); ?>" class="small-box-footer">Ver <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <br>
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="<?php echo e(asset('img/animales/vaca.jpg')); ?>" width="290" height="100" />

              
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="<?php echo e(url('/UnidadSCH/Anim/Vac')); ?>" class="small-box-footer">Ver <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <img src="<?php echo e(asset('img/animales/elefante.jpg')); ?>" width="290" height="100" />

              
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="<?php echo e(url('/UnidadSCH/Anim/Elef')); ?>" class="small-box-footer">Ver <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        
    <!-- end .sidebar1 --></div>
  <div class="content1">
    
    
    <h2>Información</h2>
    <p><textarea name="descripcion" cols="40" rows="5"  placeholder="Write something here..." readonly></textarea></p>
    <h2>Descripción</h2>
    <p><textarea name="descrion" cols="40" rows="10" placeholder="Write something here..." readonly></textarea></p>
    
    
    <!-- end .content --></div>
  </div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>