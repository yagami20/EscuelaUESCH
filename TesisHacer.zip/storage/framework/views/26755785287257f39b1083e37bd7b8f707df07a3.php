<link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/nPerro.css')); ?>">
	<script src="<?php echo e(asset('js/arch.js')); ?>"></script>
<?php $__env->startSection('content'); ?>

<div id='contentS' align='center' class="row">
    <div id="titulo">ROMPECABEZAS</div>
  	<div id='conf'>
			<span>Nro de piezas:</span>
			<select id='piezas'>
        		<option value='4'>4</option>
				<option value='9'>9</option>
				<option value='16'>16</option>
				<option value='25'>25</option>
				<option value='36'>36</option>
				<option value='0' disabled>..</option>
				<option value='0' disabled>..</option>
				<option value='100'>100</option>
			</select><input type='button' class="btn btn-outline-dark btn-sm" id='barajar' value='Barajar' />
      		<div><p>Pulsa en un cuadro y luego en otro 
      		para intercambiar sus posiciones!!</p></div>
      		<div>
      			<div id="reloj">0 : 00 : 00 : 00</div>
      		</div>
	</div>
</div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>