<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            
			<h3>Nuevo Curso</h3>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
				<?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
	</div>
</div>
			<?php echo Form::open(array('url'=>'UnidadSCH/Curso','method'=>'POST','autocomplete'=>'off','files'=>'true')); ?>

			<?php echo e(Form::token()); ?> 

		<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <!-- <form method="POST" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>"> -->
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="idNivel" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nivel')); ?></label>

                            <div class="col-md-6">
                                <select name="idNivel" class="form-control">
                                    <?php $__currentLoopData = $nivel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tpu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tpu->id); ?>" readonly="readonly" selected><?php echo e($tpu->nombreN); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <!--  -->
                        <div class="form-group row">
                            <label for="nombreP" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Paralelo')); ?></label>

                            <div class="col-md-6">
                                <input id="nombreP" type="text" placeholder="A-B-C-..." class="form-control<?php echo e($errors->has('nombreP') ? ' is-invalid' : ''); ?>" name="nombreP" value="<?php echo e(old('nombreP')); ?>" required autofocus>

                                <?php if($errors->has('nombreP')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('nombreP')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            

                            
                                <input id="nombreA" type="hidden" placeholder="A-B-C-..." class="form-control<?php echo e($errors->has('nombreP') ? ' is-invalid' : ''); ?>" name="nombreA" value="<?php echo e(old('nombreP')); ?>" required autofocus>

                        </div>
                        <!--  -->
                       <!--  <div class="form-group">
                                            <label for="inputGenero" class="col-sm-offset-2 col-sm-3 control-label">Género</label>
                                            <div class="col-sm-4">
                                              <select>
                                                <option value="Masculino">M</option>
                                                <option value="Femenino" >F</option>
                                              </select>
                                            </div>
                                        </div> -->
                        <!--  -->
                        <div class="form-group row">
                            <label for="fechaA" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fecha creación de Curso')); ?></label>

                            <div class="col-md-6">
                                <input id="fechaA" type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" placeholder="AAAA-MM-DD" class="form-control<?php echo e($errors->has('fechaA') ? ' is-invalid' : ''); ?>" name="fechaA" value="<?php echo e(old('fechaA')); ?>" required autofocus>

                                <?php if($errors->has('fechaA')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('fechaA')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        
                        <!--  -->
                        <!--  -->
                        <!--  -->
                        <!--  -->
                        
                        <!--  -->
                        
                        <!--  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    <?php echo e(__('Enviar')); ?>

                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
			
			


			<?php echo Form::close(); ?>


		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>