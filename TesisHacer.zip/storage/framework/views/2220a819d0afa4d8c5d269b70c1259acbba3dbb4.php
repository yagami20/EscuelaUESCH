    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">

		<h3>Listado de Asistencia</h3> 
	</div>
</div>

      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
            </div>
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
		 			        <th>Apellido</th>
                  
                  <th>Curso</th>
                  
                  <th>Registro</th>                
                  <th><i class="fa fa-cogs"></i> Opciones </th>
                </tr>
                <tr>
                  <?php $c = 0;$r=0; ?>
                	<?php $__currentLoopData = $userC; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                    
                  <td>UESCH<?php echo e($usd->id); ?></td>
                  <td><?php echo e($usd->nomb); ?></td>
		 			        <td><?php echo e($usd->apell); ?></td>                  
                  <td><?php echo e($usd->lvl); ?> <?php echo e($usd->cP); ?></td>
                  <td><?php $__currentLoopData = $asisR; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($usd->id==$usd1->id): ?>
                  <?php echo e($usd1->fechaAsis); ?>

                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                  <td>
                    <?php $__currentLoopData = $asisR; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $vI=$asisR[$r]->idAss;
                          $idUreg=$asisR[$r]->id;
                     ?>
                    <?php if($usd->id==$usd2->id): ?><!--registro list -->
                    <?php if($usd2->eA=='0'): ?><!--est -->
                    <a href="" data-target="#modal-registA-<?php echo e($vI); ?>" data-toggle="modal"><button type="button" class="btn btn-outline-success"><i class="fa fa-user-plus"></i> Asiste</button></a>
                    <?php else: ?>
                    <?php if($usd2->eA=='1'): ?>
                    Registrado
                    <?php endif; ?>
                    <?php endif; ?><!--fin e -->
                    <?php
                    //if($r==2){$r=0;}
                    //echo "$r"; 
                    ?>
                    <?php endif; ?><!--fin L-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    if($userC[$c]->id==$usd->id){
                      $idUf=$userC[$c]->id;
                      //if($r!=3){
                      if($userC[$c]->id==$asisR[$r]->id){
                        $r++;
                      }
                        else{                     
                          ?> 
                    <a href="" data-target="#modal-registF-<?php echo e($idUf); ?>" data-toggle="modal"><button type="button" class="btn btn-outline-danger btn-sm"><i class="fa fa-user-times"></i> Falta</button></a>
                    <?php
                    }  
                      //}
                        
                    }
                    //$c=$c+1;
                    ?>
                    <?php $c=$c+1; ?>
                    
                         
                  </td>                  
                </tr>                
                
                
                <?php echo $__env->make('Docente.Asistencia.modalA', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('Docente.Asistencia.modalF', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>               
              </table>
            </div>
            
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.docente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>