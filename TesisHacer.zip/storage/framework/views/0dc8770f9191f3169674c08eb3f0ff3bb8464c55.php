<script src="<?php echo e(asset('js/loader.js')); ?>"></script>
<?php $__env->startSection('content'); ?>
	<div class="container">
		
		<div id="piechart" style="width: 900px; height: 500px;"></div>
	</div>
<?php $__env->startPush('scripts'); ?>
<script>
 google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Tiempo', 'Usuarios'],
            <?php $__currentLoopData = $asisR; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pastels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              ['<?php echo e($pastels->tiempo); ?>', <?php echo e($pastels->n_Us); ?>],
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]);
        var options = {
          title: 'Actividades Rompecabezas'
        };
        var chart = new google.visualization.PieChart(document.getElementById('piechart'));
        chart.draw(data, options);
      }
</script>
<?php $__env->stopPush(); ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>