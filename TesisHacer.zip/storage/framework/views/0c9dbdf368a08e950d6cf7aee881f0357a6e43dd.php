    <link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
<?php $__env->startSection('content'); ?>
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"> -->
<div class="row">
	<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
    
		<h3>Reporte General Asistencia: <a href="lista/create"><button type="button" class="btn btn-outline-success"><i class="fa fa-user-plus"></i> Generar</button></a>
    <a href="" data-target="#modal-foto-<?php echo e($asisR->id='1'); ?>" data-toggle="modal"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-file-image-o"></i> Buscar</button></a></h3>
    <?php echo $__env->make('Administrador.Reportes.asistencia.modal2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		
		
    <h3>Listado de Asistencia</h3> 
	</div>
</div>



      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-striped table-bordered table-condensed table-hover">
                <tr>
                  <th>Codigo</th>
                  <th>Nombre</th>
                  <th>Fecha</th>
                  <th>Nivel</th>                
                  
                </tr>
                <tr>
                  <?php $__currentLoopData = $asisR; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                  <td>UESCH<?php echo e($usd->id); ?></td>
                  <td><?php echo e($usd->DesAsis); ?></td>
                  <td><?php echo e($usd->fechaAsis); ?></td>
                  <td><?php echo e($usd->lvl); ?> <?php echo e($usd->cP); ?></td>
                  
                    
                    
                  
                </tr>
                
                
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
              </table>
            </div>
            
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>