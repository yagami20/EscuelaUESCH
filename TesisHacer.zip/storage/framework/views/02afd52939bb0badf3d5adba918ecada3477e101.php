<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
            
			<h3>Editar Usuario: <?php echo e($usuario->name); ?></h3>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
				<?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
	</div>
</div>

	
			

<form method="POST" action="/DocenteSCH/Usuarios/<?php echo e($usuario->id); ?>" enctype="multipart/form-data">
	<?php echo method_field('PUT'); ?>
	<?php echo csrf_field(); ?>
	<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"></div>

                <div class="card-body">
                    <!-- <form method="POST" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>"> -->
                       

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" placeholder="Nombre Apellido" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($usuario->name); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--nuevos dtos  -->
                        <div class="form-group row">
                            <label for="apellido" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Apellido')); ?></label>

                            <div class="col-md-6">
                                <input id="apellido" type="text" placeholder="Nombre Apellido" class="form-control<?php echo e($errors->has('apellido') ? ' is-invalid' : ''); ?>" name="apellido" value="<?php echo e($usuario->apellido); ?>" required autofocus>

                                <?php if($errors->has('apellido')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('apellido')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                    
                        <!--  -->
                        <!--  -->
                       <!--  <div class="form-group">
                                            <label for="inputGenero" class="col-sm-offset-2 col-sm-3 control-label">Género</label>
                                            <div class="col-sm-4">
                                              <select>
                                                <option value="Masculino">M</option>
                                                <option value="Femenino" >F</option>
                                              </select>
                                            </div>
                                        </div> -->
                        <!--  -->
        
                        <!--  -->
                        
                        
                        <div class="form-group row">
                            <label for="direccion" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Dirección')); ?></label>

                            <div class="col-md-6">
                                <input id="direccion" type="text" placeholder="Direccion" class="form-control<?php echo e($errors->has('direccion') ? ' is-invalid' : ''); ?>" name="direccion" value="<?php echo e($usuario->direccion); ?>" required autofocus>

                                <?php if($errors->has('direccion')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('direccion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="telefono" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Telefono')); ?></label>

                            <div class="col-md-6">
                                <input id="telefono" type="text" placeholder="telefono" class="form-control<?php echo e($errors->has('telefono') ? ' is-invalid' : ''); ?>" name="telefono" value="<?php echo e($usuario->telefono); ?>" required autofocus>

                                <?php if($errors->has('telefono')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('telefono')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="celular" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Celular')); ?></label>

                            <div class="col-md-6">
                                <input id="celular" type="text" placeholder="celular" class="form-control<?php echo e($errors->has('celular') ? ' is-invalid' : ''); ?>" name="celular" value="<?php echo e($usuario->celular); ?>" required autofocus>

                                <?php if($errors->has('celular')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('celular')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--  -->
                        <div class="form-group row">
                            <label for="genero" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tipo de Usuario')); ?></label>

                            <div class="col-md-6">
                                <!-- <div class="col-sm-4"> -->
                                              <select name="TI" class="form-control">
                                                
                                                <option value="2" >Docente</option>
                                                <option value="3" >Estudiante</option> 
                                              </select>
                                            <!-- </div> -->

                                <?php if($errors->has('genero')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('genero')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <!--  -->
                        
                        

                        <!--fin ndatos  -->

                        

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Contraseña')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm. Contraseña')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>
                        <!--new datos  -->
                        <div class="form-group row">
                                      
                                      <div class="col-md-6">
                                      <label class="switch">
                                            
                                            <input type="hidden" name="estado" required value="0" readonly="readonly" />
                                            <div class="switch-btn"></div>
                                          </label>
                                        </div>                 
                        </div>
                        <!--estado  -->
                        <!--  -->
                        <!--  -->
                        
                        <!--  -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary offset-md-8">
                                    <?php echo e(__('Enviar')); ?>

                                </button>
                            </div>
                        </div>
                    <!-- </form> -->
                </div>
            </div>
        </div>
    </div>
</div>
</form>		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.docente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>