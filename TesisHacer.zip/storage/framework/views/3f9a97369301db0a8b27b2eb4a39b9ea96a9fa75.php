<link rel="stylesheet" href="<?php echo e(asset('css/botones.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/vLetrA.css')); ?>">
	<script src="<?php echo e(asset('js/arch.js')); ?>"></script>
<?php $__env->startSection('content'); ?>

<div id='contentS' align='center' class="row">
    <div id="titulo">ROMPECABEZAS</div>
  	<div id='conf'>
			<span>Nro de piezas:</span>
			<select id='piezas'>
        		<option value='4'>4</option>
				
				
				
				
				
				 
				
			</select><input type='button' class="btn btn-outline-dark btn-sm" id='barajar' value='Barajar' />
      		<div><p>Pulsa en un cuadro y luego en otro 
      		para intercambiar sus posiciones!!</p></div>
      		<div>
      			<div id="reloj">0 : 00 : 00 : 00</div>
      			<div>
      			<p >Registrar luego de resolver...
      			<a href="<?php echo e(URL::action('AdminRompController@verObjA',$c)); ?>"><button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-edit"></i>Registrar Tiempo</button></a></p>
      			</div>
      		</div>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>