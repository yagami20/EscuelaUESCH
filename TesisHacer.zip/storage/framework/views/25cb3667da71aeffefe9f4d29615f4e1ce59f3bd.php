<?php $__env->startSection('content'); ?>
	<div class="container">
		
		<center><h1>Clase Familia Mamá</h1></center>
		<center>
		<video width="50%" height="50%" controls>
        <source src="<?php echo e(asset('video/ayuda.mp4')); ?>" type="video/mp4">
                Your browser does not support the video tag.
      </video></center>
      <a href="<?php echo e(url('/EstudianteSCH/Fam/mama')); ?>"><button type="button" class="btn btn-outline-secondary btn-sm"><i class="fa fa-share" aria-hidden="true"></i> Siguiente</button></a>
	</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>