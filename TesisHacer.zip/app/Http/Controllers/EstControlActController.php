<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;
use Illuminate\Foundation\Auth\RegistersUsers;

use App\Nivel;
use App\paralelo;
use App\ParaleloUs;
use App\anio;
use App\User;
use App\Role;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\CursoFormRequest;


use DB; 
//

class EstControlActController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //
        $request->user()->authorizeRoles('user');
        if ($request) 
        {
        return view('Estudiante.ControlActividad.index');
        }
    }

public function indexCtVoc(Request $request)
    {
        // dd($request);

        $request->user()->authorizeRoles('user');
        // if ($request)
        // {
            /*vocales  */
        $Alum=$request->user()->name.' '.$request->user()->apellido;
        $vocal='A'; $idU=$request->user()->id;
        $user=DB::table('users as tbU')
                ->join('paralelo_user as tbPU', 'tbPU.user_id','=','tbU.id')
                ->join('paralelos as tbP', 'tbP.id','=','tbPU.paralelo_id')
                ->join('role_user as tbRU', 'tbRU.user_id','=','tbU.id')
                ->join('roles as tbR', 'tbR.id','=','tbRU.role_id')
                ->select('tbU.id','tbPU.id as idR','tbPU.paralelo_id as idPR','tbU.name as nomb','tbU.apellido as apell','tbU.direccion as direcc','tbU.telefono as telef','tbU.celular as cel','tbU.email as correo','tbR.descripcion as Rol')
                ->where('tbPU.user_id',$idU)
                ->get();
        $idP=$user[0]->idPR; $rol='docent';

        $userD=DB::table('users as tbU')
            ->join('paralelo_user as tbPU', 'tbPU.user_id','=','tbU.id')
            ->join('paralelos as tbP', 'tbP.id','=','tbPU.paralelo_id')
            ->join('role_user as tbRU', 'tbRU.user_id','=','tbU.id')
            ->join('roles as tbR', 'tbR.id','=','tbRU.role_id')
            ->select('tbU.id','tbPU.id as idR','tbU.name as nomb','tbU.apellido as apell','tbU.direccion as direcc','tbU.telefono as telef','tbU.celular as cel','tbU.email as correo','tbR.descripcion as Rol')
                ->where('tbP.id',$idP)
                ->where('tbR.name',$rol) //para obtener al docente
                ->get();
        
        $idD=$userD[0]->id; $vA='Vocales'; $VaT='16';

        $act1=DB::table('actividads as tbT')
            ->select('tbT.id')
                ->where('tbT.descripcion',$vA)
                ->get();
        $idA=$act1[0]->id;

        $Test=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaT)
                ->get();
        if(isset($Test[0])){
        $descT=$Test[0]->desTest;
        /*vocal A */
        $VocalA=DB::table('desactivs as D')
        ->join('seccion_activs as SA','D.idSecact','=','SA.id')
        ->select('D.Alumno','D.id','D.tiempo')
        ->where('D.Alumno',$Alum)
        ->where('SA.descripcion',$vocal)
        ->get();

        // dd($VocalA);

        $TestA=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descT)
        ->get();
        }
        else{$TestA=$Test;}
        // dd($TestA);

        /*vocal E */
        $vocalE='E'; $VaTe='17';
        $testE=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaTe)
                ->get();
        if(isset($testE[0])){
        $descTe=$testE[0]->desTest;

        // dd($descTe);
        $VocalE=DB::table('desactivs as D')
        ->join('seccion_activs as SA','D.idSecact','=','SA.id')
        ->select('D.Alumno','D.id','D.tiempo')
        ->where('D.Alumno',$Alum)
        ->where('SA.descripcion',$vocalE)
        ->get();



        $TestE=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descTe)
        ->get();
        }
        else{$TestE=$testE;}
        // dd($TestE);
        /* vocal I */
        $vocalI='I'; $VaTi='18';
        $testI=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaTi)
                ->get();
        if(isset($testI[0])){
        $descTi=$testI[0]->desTest;

        $VocalI=DB::table('desactivs as D')
        ->join('seccion_activs as SA','D.idSecact','=','SA.id')
        ->select('D.Alumno','D.id','D.tiempo')
        ->where('D.Alumno',$Alum)
        ->where('SA.descripcion',$vocalI)
        ->get();



        $TestI=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descTi)
        ->get();
        }
        else{$TestI=$testI;}

        /* vocal O */
        // dd($TestI);
        $vocalO='O'; $VaTo='19';
        $testO=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaTo)
                ->get();
        
        if(isset($testO[0])){
        $descTo=$testO[0]->desTest;

        
        $VocalO=DB::table('desactivs as D')
        ->join('seccion_activs as SA','D.idSecact','=','SA.id')
        ->select('D.Alumno','D.id','D.tiempo')
        ->where('D.Alumno',$Alum)
        ->where('SA.descripcion',$vocalO)
        ->get();


        $TestO=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descTo)
        ->get();
        }
        else{
            $TestO=$testO;
        }
        


        /* vocal U */
        $vocalU='U'; $VaTu='20';
        $testU=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaTu)
                ->get();
        if(isset($testU[0])){
        $descTu=$testU[0]->desTest;

        
        $VocalU=DB::table('desactivs as D')
        ->join('seccion_activs as SA','D.idSecact','=','SA.id')
        ->select('D.Alumno','D.id','D.tiempo')
        ->where('D.Alumno',$Alum)
        ->where('SA.descripcion',$vocalU)
        ->get();

        $TestU=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descTu)
        ->get();
        }
        else{
            $TestU=$testU;
        }
        return view ('Estudiante.ControlActividad.vocales.index',["VocalA"=>$VocalA,"TestA"=>$TestA,"TestE"=>$TestE,"TestI"=>$TestI,"TestO"=>$TestO,"TestU"=>$TestU]);
        // }
    }

    public function indexCtNum(Request $request)
    {
        $request->user()->authorizeRoles('user');
        if ($request)
        {
            /*Numeros */
        $Alum=$request->user()->name.' '.$request->user()->apellido;
        $idU=$request->user()->id;
        $user=DB::table('users as tbU')
                ->join('paralelo_user as tbPU', 'tbPU.user_id','=','tbU.id')
                ->join('paralelos as tbP', 'tbP.id','=','tbPU.paralelo_id')
                ->join('role_user as tbRU', 'tbRU.user_id','=','tbU.id')
                ->join('roles as tbR', 'tbR.id','=','tbRU.role_id')
                ->select('tbU.id','tbPU.id as idR','tbPU.paralelo_id as idPR','tbU.name as nomb','tbU.apellido as apell','tbU.direccion as direcc','tbU.telefono as telef','tbU.celular as cel','tbU.email as correo','tbR.descripcion as Rol')
                ->where('tbPU.user_id',$idU)
                ->get();
        $idP=$user[0]->idPR; $rol='docent';

        $userD=DB::table('users as tbU')
            ->join('paralelo_user as tbPU', 'tbPU.user_id','=','tbU.id')
            ->join('paralelos as tbP', 'tbP.id','=','tbPU.paralelo_id')
            ->join('role_user as tbRU', 'tbRU.user_id','=','tbU.id')
            ->join('roles as tbR', 'tbR.id','=','tbRU.role_id')
            ->select('tbU.id','tbPU.id as idR','tbU.name as nomb','tbU.apellido as apell','tbU.direccion as direcc','tbU.telefono as telef','tbU.celular as cel','tbU.email as correo','tbR.descripcion as Rol')
                ->where('tbP.id',$idP)
                ->where('tbR.name',$rol) //para obtener al docente
                ->get();
        
        $idD=$userD[0]->id; $vA='Numeros'; $VaT='11';

        $act1=DB::table('actividads as tbT')
            ->select('tbT.id')
                ->where('tbT.descripcion',$vA)
                ->get();
        // dd($act1);
        $idA=$act1[0]->id;

        $Test=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaT)
                ->get();
        if(isset($Test[0])){
        $descT=$Test[0]->desTest;
        /*vocal A */

        $Test1=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descT)
        ->get();
        }
        else{$Test1=$Test;}
        // dd($TestA);

        /*vocal E */
        $VaTe='12';
        $testE=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaTe)
                ->get();
        if(isset($testE[0])){
        $descTe=$testE[0]->desTest;

        $Test2=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descTe)
        ->get();
        }
        else{$Test2=$testE;}
        // dd($TestE);
        /* vocal I */
        $VaTi='13';
        $testI=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaTi)
                ->get();
        if(isset($testI[0])){
        $descTi=$testI[0]->desTest;

        $Test3=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descTi)
        ->get();
        }
        else{$Test3=$testI;}

        /* vocal O */
        // dd($TestI);
        $VaTo='14';
        $testO=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaTo)
                ->get();
        
        if(isset($testO[0])){
        $descTo=$testO[0]->desTest;
        $Test4=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descTo)
        ->get();
        }
        else{
            $Test4=$testO;
        }
        


        /* vocal U */
        $VaTu='15';
        $testU=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaTu)
                ->get();
        if(isset($testU[0])){
        $descTu=$testU[0]->desTest;

        $Test5=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descTu)
        ->get();
        }
        else{
            $Test5=$testU;
        }
            /* */
        return view('Estudiante.ControlActividad.numeros.index',["Test1"=>$Test1,"Test2"=>$Test2,"Test3"=>$Test3,"Test4"=>$Test4,"Test5"=>$Test5]);
        }
    }

    public function indexCtFam(Request $request)
    {
        $request->user()->authorizeRoles('user');
        if ($request)
        {
            /*familia */
        $Alum=$request->user()->name.' '.$request->user()->apellido;
        $idU=$request->user()->id;
        $user=DB::table('users as tbU')
                ->join('paralelo_user as tbPU', 'tbPU.user_id','=','tbU.id')
                ->join('paralelos as tbP', 'tbP.id','=','tbPU.paralelo_id')
                ->join('role_user as tbRU', 'tbRU.user_id','=','tbU.id')
                ->join('roles as tbR', 'tbR.id','=','tbRU.role_id')
                ->select('tbU.id','tbPU.id as idR','tbPU.paralelo_id as idPR','tbU.name as nomb','tbU.apellido as apell','tbU.direccion as direcc','tbU.telefono as telef','tbU.celular as cel','tbU.email as correo','tbR.descripcion as Rol')
                ->where('tbPU.user_id',$idU)
                ->get();
        $idP=$user[0]->idPR; $rol='docent';

        $userD=DB::table('users as tbU')
            ->join('paralelo_user as tbPU', 'tbPU.user_id','=','tbU.id')
            ->join('paralelos as tbP', 'tbP.id','=','tbPU.paralelo_id')
            ->join('role_user as tbRU', 'tbRU.user_id','=','tbU.id')
            ->join('roles as tbR', 'tbR.id','=','tbRU.role_id')
            ->select('tbU.id','tbPU.id as idR','tbU.name as nomb','tbU.apellido as apell','tbU.direccion as direcc','tbU.telefono as telef','tbU.celular as cel','tbU.email as correo','tbR.descripcion as Rol')
                ->where('tbP.id',$idP)
                ->where('tbR.name',$rol) //para obtener al docente
                ->get();
        
        $idD=$userD[0]->id; $vA='Familia'; $VaT='6';

        $act1=DB::table('actividads as tbT')
            ->select('tbT.id')
                ->where('tbT.descripcion',$vA)
                ->get();
        // dd($act1);
        $idA=$act1[0]->id;

        $Test=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaT)
                ->get();
        if(isset($Test[0])){
        $descT=$Test[0]->desTest;
        /*vocal A */

        $Test1=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descT)
        ->get();
        }
        else{$Test1=$Test;}
        // dd($TestA);

        /*vocal E */
        $VaTe='7';
        $testE=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaTe)
                ->get();
        if(isset($testE[0])){
        $descTe=$testE[0]->desTest;

        $Test2=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descTe)
        ->get();
        }
        else{$Test2=$testE;}
        // dd($TestE);
        /* vocal I */
        $VaTi='8';
        $testI=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaTi)
                ->get();
        if(isset($testI[0])){
        $descTi=$testI[0]->desTest;

        $Test3=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descTi)
        ->get();
        }
        else{$Test3=$testI;}

        /* vocal O */
        // dd($TestI);
        $VaTo='9';
        $testO=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaTo)
                ->get();
        
        if(isset($testO[0])){
        $descTo=$testO[0]->desTest;
        $Test4=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descTo)
        ->get();
        }
        else{
            $Test4=$testO;
        }
        


        /* vocal U */
        $VaTu='10';
        $testU=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaTu)
                ->get();
        if(isset($testU[0])){
        $descTu=$testU[0]->desTest;

        $Test5=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descTu)
        ->get();
        }
        else{
            $Test5=$testU;
        }
            /* */
        return view('Estudiante.ControlActividad.familia.index',["Test1"=>$Test1,"Test2"=>$Test2,"Test3"=>$Test3,"Test4"=>$Test4,"Test5"=>$Test5]);
        }
    }

    public function indexCtAnim(Request $request)
    {
        $request->user()->authorizeRoles('user');
        if ($request)
        {
            /*Animales */
        $Alum=$request->user()->name.' '.$request->user()->apellido;
        $idU=$request->user()->id;
        $user=DB::table('users as tbU')
                ->join('paralelo_user as tbPU', 'tbPU.user_id','=','tbU.id')
                ->join('paralelos as tbP', 'tbP.id','=','tbPU.paralelo_id')
                ->join('role_user as tbRU', 'tbRU.user_id','=','tbU.id')
                ->join('roles as tbR', 'tbR.id','=','tbRU.role_id')
                ->select('tbU.id','tbPU.id as idR','tbPU.paralelo_id as idPR','tbU.name as nomb','tbU.apellido as apell','tbU.direccion as direcc','tbU.telefono as telef','tbU.celular as cel','tbU.email as correo','tbR.descripcion as Rol')
                ->where('tbPU.user_id',$idU)
                ->get();
        $idP=$user[0]->idPR; $rol='docent';

        $userD=DB::table('users as tbU')
            ->join('paralelo_user as tbPU', 'tbPU.user_id','=','tbU.id')
            ->join('paralelos as tbP', 'tbP.id','=','tbPU.paralelo_id')
            ->join('role_user as tbRU', 'tbRU.user_id','=','tbU.id')
            ->join('roles as tbR', 'tbR.id','=','tbRU.role_id')
            ->select('tbU.id','tbPU.id as idR','tbU.name as nomb','tbU.apellido as apell','tbU.direccion as direcc','tbU.telefono as telef','tbU.celular as cel','tbU.email as correo','tbR.descripcion as Rol')
                ->where('tbP.id',$idP)
                ->where('tbR.name',$rol) //para obtener al docente
                ->get();
        
        $idD=$userD[0]->id; $vA='Animales'; $VaT='1';

        $act1=DB::table('actividads as tbT')
            ->select('tbT.id')
                ->where('tbT.descripcion',$vA)
                ->get();
        // dd($act1);
        $idA=$act1[0]->id;

        $Test=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaT)
                ->get();
        if(isset($Test[0])){
        $descT=$Test[0]->desTest;
        /*vocal A */

        $Test1=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descT)
        ->get();
        }
        else{$Test1=$Test;}
        // dd($TestA);

        /*vocal E */
        $VaTe='2';
        $testE=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaTe)
                ->get();
        if(isset($testE[0])){
        $descTe=$testE[0]->desTest;

        $Test2=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descTe)
        ->get();
        }
        else{$Test2=$testE;}
        // dd($TestE);
        /* vocal I */
        $VaTi='3';
        $testI=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaTi)
                ->get();
        if(isset($testI[0])){
        $descTi=$testI[0]->desTest;

        $Test3=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descTi)
        ->get();
        }
        else{$Test3=$testI;}

        /* vocal O */
        // dd($TestI);
        $VaTo='4';
        $testO=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaTo)
                ->get();
        
        if(isset($testO[0])){
        $descTo=$testO[0]->desTest;
        $Test4=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descTo)
        ->get();
        }
        else{
            $Test4=$testO;
        }
        


        /* vocal U */
        $VaTu='5';
        $testU=DB::table('tests as tbT')
            ->join('test_user as tbTU', 'tbTU.test_id','=','tbT.id')
            ->join('users as tbU', 'tbU.id','=','tbTU.user_id')
            ->select('tbT.id','tbT.desTest','tbT.tipoTest','tbT.selecTest')
                ->where('tbU.id',$idD)
                ->where('tbT.tipoTest',$idA)
                ->where('tbT.selecTest',$VaTu)
                ->get();
        if(isset($testU[0])){
        $descTu=$testU[0]->desTest;

        $Test5=DB::table('destests as DT')
        ->select('DT.id','DT.notaDes','DT.descTest','DT.fechaDes','DT.nombUsDes')
        ->where('DT.nombUsDes',$Alum)
        ->where('DT.descTest',$descTu)
        ->get();
        }
        else{
            $Test5=$testU;
        }
        return view('Estudiante.ControlActividad.animales.index',["Test1"=>$Test1,"Test2"=>$Test2,"Test3"=>$Test3,"Test4"=>$Test4,"Test5"=>$Test5]);
        }
    }
    

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */ 
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
