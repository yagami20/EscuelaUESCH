<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;
use Illuminate\Foundation\Auth\RegistersUsers;

use App\User;
use App\Desactiv;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use DB;
//

class AdminRompController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    //VOCALES 
    public function indexA(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        // dd($c);
        if ($request)
        {
            return view ('Administrador.Rompecabezas.vocales.a.index',["c"=>$c]);            
        }
    }

    public function indexE(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.vocales.e.index',["c"=>$c]);            
        }
    }

    public function indexI(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.vocales.i.index',["c"=>$c]);            
        }
    }

    public function indexO(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.vocales.o.index',["c"=>$c]);            
        }
    }

    public function indexU(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.vocales.u.index',["c"=>$c]);            
        }
    }
    //
    //NUMEROS 
    public function indexNU(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.numeros.1.index',["c"=>$c]);            
        }
    }

    public function indexND(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.numeros.2.index',["c"=>$c]);            
        }
    }

    public function indexNT(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.numeros.3.index',["c"=>$c]);            
        }
    }

    public function indexNC(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.numeros.4.index',["c"=>$c]);            
        }
    }

    public function indexNCC(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.numeros.5.index',["c"=>$c]);            
        }
    }
     //
     //FAMILIA 
    public function indexPa(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.familia.papa.index',["c"=>$c]);            
        }
    }

    public function indexMa(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.familia.mama.index',["c"=>$c]);            
        }
    }

    public function indexHer(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.familia.hermano.index',["c"=>$c]);            
        }
    }

    public function indexAbu(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.familia.abuelo.index',["c"=>$c]);            
        }
    }

    public function indexPri(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.familia.primo.index',["c"=>$c]);            
        }
    }
     //ANIMALES 
    public function indexElef(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.animales.elef.index',["c"=>$c]);            
        }
    }

    public function indexGall(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.animales.gallo.index',["c"=>$c]);            
        }
    }

    public function indexGat(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.animales.gato.index',["c"=>$c]);            
        }
    }

    public function indexPerr(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.animales.perro.index',["c"=>$c]);            
        }
    }

    public function indexVac(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Administrador.Rompecabezas.animales.vaca.index',["c"=>$c]);            
        }
    }
     // 

    public function index (Request $request)
    {

        $request->user()->authorizeRoles('admin');
        if ($request)
        {
            return view ('Administrador.Rompecabezas.vocales.index');            
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /*
     * funciones de recepcion de respuesta rompecabezas
     * @return \Illuminate\Http\Response
     */
    //VOCALES
    public function verObjA(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='A'; $VaT='1';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes; 
            $Des->save();
            return redirect()->action('AdminContTestController@verTestA', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestA', [$VaT]);
        }
        //   
    }

    public function verObjE(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='E'; $VaT='2';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestE', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestE', [$VaT]);
        }
        //   
    }

    public function verObjI(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='I'; $VaT='3';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestI', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestI', [$VaT]);
        }
        //   
    }

    public function verObjO(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='O'; $VaT='4';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestO', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestO', [$VaT]);
        }
        //   
    }

    public function verObjU(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='U'; $VaT='5';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestU', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestU', [$VaT]);
        }
        //   
    }

    //NUMEROS
    public function verObjNU(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Uno'; $VaT='1';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestNU', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestNU', [$VaT]);
        }
        //   
    }

    public function verObjND(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Dos'; $VaT='2';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestND', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestND', [$VaT]);
        }
        //   
    }

    public function verObjNT(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Tres'; $VaT='3';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestNT', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestNT', [$VaT]);
        }
        //   
    }

    public function verObjNC(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Cuatro'; $VaT='4';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestNC', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestNC', [$VaT]);
        }
        //   
    }

    public function verObjNCC(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Cinco'; $VaT='5';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestNCC', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestNCC', [$VaT]);
        }
        //   
    }

    //FAMILIA
    public function verObjPa(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Papá'; $VaT='4';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestPA', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestPA', [$VaT]);
        }
        //   
    }

    public function verObjMa(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Mamá'; $VaT='3';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestMA', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestMA', [$VaT]);
        }
        //   
    }

    public function verObjHer(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Hermano'; $VaT='2';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestHER', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestHER', [$VaT]);
        }
        //   
    }

    public function verObjAbu(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Abuelo'; $VaT='1';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestABU', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestABU', [$VaT]);
        }
        //   
    }

    public function verObjPri(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Primo'; $VaT='5';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestPRI', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestPRI', [$VaT]);
        }
        //   
    }

    //ANIMALES
    public function verObjElef(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Elefante'; $VaT='1';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestELEF', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestELEF', [$VaT]);
        }
        //   
    }

    public function verObjGall(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Gallo'; $VaT='2';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestGall', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestGall', [$VaT]);
        }
        //   
    }

    public function verObjGat(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Gato'; $VaT='3';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestGat', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestGat', [$VaT]);
        }
        //   
    }

    public function verObjPerr(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Perro'; $VaT='4';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestPerr', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestPerr', [$VaT]);
        }
        //   
    }

    public function verObjVac(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['admin']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Vaca'; $VaT='5';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        // dd($desAct);
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            // dd($n);
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('AdminContTestController@verTestVac', [$VaT]);
        }
        else{
            // dd($e);
            
            // dd($vA);
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('AdminContTestController@verTestVac', [$VaT]);
        }
        //   
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
