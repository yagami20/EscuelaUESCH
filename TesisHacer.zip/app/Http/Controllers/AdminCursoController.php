<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;
use Illuminate\Foundation\Auth\RegistersUsers;

use App\Nivel;
use App\paralelo;
use App\anio;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\CursoFormRequest;
// use App\Http\Requests\UserUpdateFormRequest;


use DB;
//

class AdminCursoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index (Request $request)
    {

        $request->user()->authorizeRoles('admin');
        if ($request)
        {
        
            $query=trim($request->get('searchText')); //determinr texto de busqueda

            
            $curso=DB::table('nivels as tbN')
            ->join('paralelos as tbP', 'tbN.id','=','tbP.idNivel')
            ->join('anios as tbA', 'tbN.id','=','tbA.idNivel')
            ->select('tbP.id','tbA.id as idA','tbP.nombreP as Paralel','tbN.nombreN as Nivel','tbA.fechaA as fecha')
            
            ->orwhere('tbP.nombreP','LIKE','%'.$query.'%')
            ->orwhere('tbN.nombreN','LIKE','%'.$query.'%')
            ->orwhere('tbA.fechaA','LIKE','%'.$query.'%')
            
            ->orderBy('tbP.id','desc')

            ->paginate(7);

            return view ('Administrador.Curso.index',["curso"=>$curso,"searchText"=>$query]);
            
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $request->user()->authorizeRoles('admin');
        $nivel=DB::table('nivels')->get();
        return view ("Administrador.Curso.create",["nivel"=>$nivel]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store (CursoFormRequest $request)
    {
        // dd($request);
        $parll=new paralelo;

        $parll->nombreP=$request->get('nombreP');

        $parll->idNivel=$request->get('idNivel');

        $parll->save();

        $this->addProduct($parll->id,$request);

        return Redirect::to('UnidadSCH/Curso');
    }

    public function addProduct ($idP,$request)
    {
        $fecha= new anio;//llamar
        $fecha->nombreA=$request->get('nombreP');
        $fecha->fechaA=$request->get('fechaA');
        $fecha->idNivel=$request->get('idNivel');

        $fecha->save();
        
                
        return Redirect::to('UnidadSCH/Curso');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show (paralelo $paralelo)
    {

        return view("Administrador.Curso.show",compact('paralelo'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {

        $request->user()->authorizeRoles(['admin','user']);
        // $curso=DB::table('paralelos as tbP')
        //     ->join('nivels as tbN', 'tbN.id','=','tbP.idNivel')
        //     ->join('anios as tbA', 'tbA.idNivel','=','tbP.idNivel')
        //     ->select('tbP.id as idP','tbA.id as idA','tbN.id as idN')
        //     ->Where('tbP.id','LIKE','%'.$id.'%')
        //     ->get();
        //     dd($curso);

        $parall=paralelo::findOrFail($id);
        $nivel=Nivel::findOrFail($parall->idNivel);
        $anio=anio::findOrFail($id);
        return view("Administrador.Curso.edit",["anio"=>$anio,"parall"=>$parall,"nivel"=>$nivel]);
        
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(CursoFormRequest $request, $id)
    {

        $parll=paralelo::findOrFail($id);

        $parll->nombreP=$request->get('nombreP');

        $parll->idNivel=$request->get('idNivel2');

        $parll->save();

        $this->modProduct($parll->id,$request);

        return Redirect::to('UnidadSCH/Curso');
        
    }

    public function modProduct ($idApp,$request)
    {
        $fecha= anio::findOrFail($idApp);
        $fecha->nombreA=$request->get('nombreP');
        $fecha->fechaA=$request->get('fechaA');
        $fecha->idNivel=$request->get('idNivel2');
        $fecha->save();
                
        return Redirect::to('UnidadSCH/Curso');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $prod=paralelo::findOrFail($id);
        $idApp=$prod->id;
        $prod->delete();
        $apg=anio::findOrFail($idApp);
        $apg->delete();
        return Redirect::to('UnidadSCH/Curso');
    }
}
