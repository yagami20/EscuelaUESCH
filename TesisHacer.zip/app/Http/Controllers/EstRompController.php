<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;
use Illuminate\Foundation\Auth\RegistersUsers;

use App\User;
use App\Desactiv;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

use DB;
//

class EstRompController extends Controller
{
    /**
     * Display a listing of the resource.
     * 
     * @return \Illuminate\Http\Response
     */
    public function __construct() 
    {
        $this->middleware('auth');
    }

    //VOCALES 
    public function indexA(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.vocales.a.index',["c"=>$c]);            
        }
    }

    public function indexE(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.vocales.e.index',["c"=>$c]);            
        }
    }

    public function indexI(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.vocales.i.index',["c"=>$c]);            
        }
    }

    public function indexO(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.vocales.o.index',["c"=>$c]);            
        }
    }

    public function indexU(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.vocales.u.index',["c"=>$c]);            
        }
    }
    //
    //NUMEROS 
    public function indexNU(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.numeros.1.index',["c"=>$c]);            
        }
    }

    public function indexND(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.numeros.2.index',["c"=>$c]);            
        }
    }

    public function indexNT(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.numeros.3.index',["c"=>$c]);            
        }
    }

    public function indexNC(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.numeros.4.index',["c"=>$c]);            
        }
    }

    public function indexNCC(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.numeros.5.index',["c"=>$c]);            
        }
    }
     //
     //FAMILIA 
    public function indexPa(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.familia.papa.index',["c"=>$c]);            
        }
    }

    public function indexMa(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.familia.mama.index',["c"=>$c]);            
        }
    }

    public function indexHer(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.familia.hermano.index',["c"=>$c]);            
        }
    }

    public function indexAbu(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.familia.abuelo.index',["c"=>$c]);            
        }
    }

    public function indexPri(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.familia.primo.index',["c"=>$c]);            
        }
    }
     //ANIMALES 
    public function indexElef(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.animales.elef.index',["c"=>$c]);            
        }
    }

    public function indexGall(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.animales.gallo.index',["c"=>$c]);            
        }
    }

    public function indexGat(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.animales.gato.index',["c"=>$c]);            
        }
    }

    public function indexPerr(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.animales.perro.index',["c"=>$c]);            
        }
    }

    public function indexVac(Request $request)
    {
        $request->user()->authorizeRoles('user');
        $m=date("i");
        $s=date("s");
        $c=$m.":".$s;
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.animales.vaca.index',["c"=>$c]);            
        }
    }
     // 

    public function index (Request $request)
    {

        $request->user()->authorizeRoles('user');
        if ($request)
        {
            return view ('Estudiante.Rompecabezas.vocales.index');            
        }
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    //VOCALES
    public function verObjA(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='A'; $VaT='1';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestA', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestA', [$VaT]);
        }
        //   
    }

    public function verObjE(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='E'; $VaT='2';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestE', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestE', [$VaT]);
        }
        //   
    }

    public function verObjI(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='I'; $VaT='3';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestI', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestI', [$VaT]);
        }
        //   
    }

    public function verObjO(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='O'; $VaT='4';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestO', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestO', [$VaT]);
        }
        //   
    }

    public function verObjU(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='U'; $VaT='5';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestU', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestU', [$VaT]);
        }
        //   
    }

    //NUMEROS
    public function verObjNU(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Uno'; $VaT='1';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestNU', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestNU', [$VaT]);
        }
        //   
    }

    public function verObjND(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Dos'; $VaT='2';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestND', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestND', [$VaT]);
        }
        //   
    }

    public function verObjNT(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Tres'; $VaT='3';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestNT', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestNT', [$VaT]);
        }
        //   
    }

    public function verObjNC(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Cuatro'; $VaT='4';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestNC', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestNC', [$VaT]);
        }
        //   
    }

    public function verObjNCC(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Cinco'; $VaT='5';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestNCC', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestNCC', [$VaT]);
        }
        //   
    }

    //FAMILIA
    public function verObjPa(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Papá'; $VaT='4';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestPA', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestPA', [$VaT]);
        }
        //   
    }

    public function verObjMa(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Mamá'; $VaT='3';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestMA', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestMA', [$VaT]);
        }
        //   
    }

    public function verObjHer(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Hermano'; $VaT='2';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestHER', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestHER', [$VaT]);
        }
        //   
    }

    public function verObjAbu(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Abuelo'; $VaT='1';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestABU', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestABU', [$VaT]);
        }
        //   
    }

    public function verObjPri(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Primo'; $VaT='5';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestPRI', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestPRI', [$VaT]);
        }
        //   
    }

    //ANIMALES
    public function verObjElef(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Elefante'; $VaT='1';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestELEF', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestELEF', [$VaT]);
        }
        //   
    }

    public function verObjGall(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Gallo'; $VaT='2';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestGall', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestGall', [$VaT]);
        }
        //   
    }

    public function verObjGat(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Gato'; $VaT='3';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestGat', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestGat', [$VaT]);
        }
        //   
    }

    public function verObjPerr(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Perro'; $VaT='4';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestPerr', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestPerr', [$VaT]);
        }
        //   
    }

    public function verObjVac(Request $request,$reloj)
    {
        $request->user()->authorizeRoles(['user']);
        $m=$reloj[0].$reloj[1];
        $s=$reloj[3].$reloj[4];

        $m1=date("i");
        $s1=date("s");
        $c1=$m.":".$s;

        $rm1=($m-$m1)*-1;
        $rs1=($s-$s1);
        if($rs1<=0){
            $rs1=$rs1*-1;
        }

        $c2=$rm1.":".$rs1;
        
        //fin cronom
        $vA='Vaca'; $VaT='5';
        $AcT=DB::table('seccion_activs as tbSA')
            ->join('actividads as tbA', 'tbA.id','=','tbSA.idActiv')
            ->select('tbSA.id','tbSA.descripcion','tbSA.idActiv')
            ->where('tbSA.descripcion',$vA)
            ->get();
        $idUs=$request->user()->id; //id
        $Alum=$request->user()->name.' '.$request->user()->apellido; //nombre
        $P_Des=User::where('id',$idUs)->first(); //selec alumn
        $idA=$AcT[0]->id; //idSecActiv
        
        $desAct=DB::table('desactivs as tbSA')
            ->select('tbSA.id','tbSA.estado','tbSA.tiempo')
            ->where('tbSA.idSecact',$idA)
            ->where('tbSA.Alumno',$Alum)
            ->get();
        $e='existe'; $n='vacio';
        if(isset($desAct[0]))
        {
            $idDes=$desAct[0]->id;
            $tDes=$desAct[0]->tiempo;
            $Des=Desactiv::findOrFail($idDes);
            $Des->tiempo=$c2;
            $Des->tiempoV=$tDes;
            $Des->save();
            return redirect()->action('EstContTestController@verTestVac', [$VaT]);
        }
        else{
            $Des=new Desactiv;
            $Des->estado='1';
            $Des->tiempo=$c2;
            $Des->tiempoV='0';
            $Des->Alumno=$Alum;
            $Des->idSecact=$idA;
            $Des->save();
            $Des->users()->attach($P_Des);
            return redirect()->action('EstContTestController@verTestVac', [$VaT]);
        }
        //   
    }

}

