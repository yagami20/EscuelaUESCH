<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;
use Illuminate\Foundation\Auth\RegistersUsers;

use App\Nivel;
use App\Asistencia;
use App\paralelo;
use App\ParaleloUs;
use App\anio;
use App\User;
use App\Role;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\CursoFormRequest;
// use App\Http\Requests\UserUpdateFormRequest;


use DB;
//

class EstAsistController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index (Request $request)
    {

        $request->user()->authorizeRoles('user');
        $idU=$request->user()->id;
        $user=DB::table('users as tbU')
                ->join('paralelo_user as tbPU', 'tbPU.user_id','=','tbU.id')
                ->join('paralelos as tbP', 'tbP.id','=','tbPU.paralelo_id')
                ->join('role_user as tbRU', 'tbRU.user_id','=','tbU.id')
                ->join('roles as tbR', 'tbR.id','=','tbRU.role_id')
                ->select('tbU.id','tbPU.id as idR','tbPU.paralelo_id as idPR','tbU.name as nomb','tbU.apellido as apell','tbU.direccion as direcc','tbU.telefono as telef','tbU.celular as cel','tbU.email as correo','tbR.descripcion as Rol')
                ->where('tbPU.user_id',$idU)
                ->get();
        // dd($user);
        $asisR=DB::table('users as tbU')
                ->join('paralelo_user as tbPU', 'tbPU.user_id','=','tbU.id')
                ->join('paralelos as tbP', 'tbP.id','=','tbPU.paralelo_id')
                ->join('nivels as tbNi', 'tbNi.id','=','tbP.idNivel')
                ->join('role_user as tbRU', 'tbRU.user_id','=','tbU.id')
                ->join('roles as tbR', 'tbR.id','=','tbRU.role_id')
                ->join('asistencia_user as tbAU', 'tbAU.user_id','=','tbU.id')
                ->join('asistencias as tbAs', 'tbAs.id','=','tbAU.asistencia_id')
                ->select('tbU.id','tbPU.id as idR','tbPU.paralelo_id as idPR','tbU.name as nomb','tbU.apellido as apell','tbU.direccion as direcc','tbU.telefono as telef','tbU.celular as cel','tbU.email as correo','tbR.descripcion as Rol','tbAs.id as idAss','tbAs.DescripAsis as desAss','tbAs.fechaAsis','tbNi.nombreN as lvl','tbP.nombreP as cP')
                // ->where('tbPU.user_id',$idU)
                ->get();
        // dd($asisR);
        $idP=$user[0]->idPR;

        $parall=paralelo::findOrFail($idP);

        $nivel=Nivel::findOrFail($parall->idNivel);
        
        $anio=anio::findOrFail($idP);
        $user=DB::table('users as tbU')
            ->select('tbU.id','tbU.name','tbU.apellido','tbU.direccion','tbU.telefono','tbU.celular','tbU.email')
            ->where ('tbU.estado','=','0')
            ->get();
        $valor=$idP;
        if ($request)
        {
        
            return view ('Estudiante.Asistencia.index',["valor"=>$valor,"asisR"=>$asisR,"user"=>$user,"parall"=>$parall,"nivel"=>$nivel,"anio"=>$anio]);
            
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store (Request $request)
    {
        /*
        $request->user()->authorizeRoles('admin');
        $idU=$request->user()->id;
        // 
        $P=DB::table('paralelos as tbU')
            ->select('tbU.id as id')
            ->get();
        $det=paralelo::findOrFail($id);
        $nomb=$det->id;
                $P_Des=paralelo::where('id',$nomb)->first();

        $us=User::findOrFail($request->idUser);
        $us->estado=$request->get('estado');
        $us->save();
        $us->Asistencias()->attach($P_Des);
        */
        //
        $f=date_create()->format('Y-m-d H:i:s');
        $request->user()->authorizeRoles('user');
        $idN=$request->user()->name.' '.$request->user()->apellido;
        $idUR=$request->user()->id;
        $P_Des=User::where('id',$idUR)->first();
        // dd($P_Des);
        $ass=new Asistencia;

        $ass->DescripAsis=$idN;

        $ass->fechaAsis=$f;

        $ass->estado='0';

        $ass->save();

        $asR=Asistencia::where('id',$ass->id)->first();
        // dd($asR);

        $P_Des->asistencias()->attach($asR);
         // 
        
        return Redirect::to('EstudianteSCH/Asistencia');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
