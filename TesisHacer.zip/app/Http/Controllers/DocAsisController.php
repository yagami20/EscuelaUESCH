<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//llamado
use App\Http\Requests;
use Illuminate\Foundation\Auth\RegistersUsers;

use App\Nivel;
use App\Asistencia;
use App\paralelo;
use App\ParaleloUs;
use App\anio;
use App\User;
use App\Role;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\CursoFormRequest;
// use App\Http\Requests\UserUpdateFormRequest;


use DB;
// 

class DocAsisController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index (Request $request)
    {

        $request->user()->authorizeRoles('docent');
        $idU=$request->user()->id;
        $user=DB::table('users as tbU')
                ->join('paralelo_user as tbPU', 'tbPU.user_id','=','tbU.id')
                ->join('paralelos as tbP', 'tbP.id','=','tbPU.paralelo_id')
                ->join('role_user as tbRU', 'tbRU.user_id','=','tbU.id')
                ->join('roles as tbR', 'tbR.id','=','tbRU.role_id')
                ->select('tbU.id','tbPU.id as idR','tbPU.paralelo_id as idPR','tbU.name as nomb','tbU.apellido as apell','tbU.direccion as direcc','tbU.telefono as telef','tbU.celular as cel','tbU.email as correo','tbR.descripcion as Rol')
                ->where('tbPU.user_id',$idU)
                ->get();
        // dd($user);
                $f2=date_create()->format('Y-m-d');
                $f1=date_create()->format('Y-m-d');
        $asisR=DB::table('users as tbU')
                ->join('paralelo_user as tbPU', 'tbPU.user_id','=','tbU.id')
                ->join('paralelos as tbP', 'tbP.id','=','tbPU.paralelo_id')
                ->join('nivels as tbNi', 'tbNi.id','=','tbP.idNivel')
                ->join('role_user as tbRU', 'tbRU.user_id','=','tbU.id')
                ->join('roles as tbR', 'tbR.id','=','tbRU.role_id')
                ->join('asistencia_user as tbAU', 'tbAU.user_id','=','tbU.id')
                ->join('asistencias as tbAs', 'tbAs.id','=','tbAU.asistencia_id')
                ->select('tbU.id','tbPU.id as idR','tbPU.paralelo_id as idPR','tbU.name as nomb','tbU.apellido as apell','tbU.direccion as direcc','tbU.telefono as telef','tbU.celular as cel','tbU.email as correo','tbR.descripcion as Rol','tbAs.id as idAss','tbAs.DescripAsis as desAss','tbAs.fechaAsis','tbNi.nombreN as lvl','tbP.nombreP as cP','tbAs.estado as eA')
                ->whereBetween('tbAs.fechaAsis',[$f1,$f2])
                // ->where('tbPU.user_id',$idU)
                ->get();
        $cAsis = DB::table('users as tbU')
                ->join('paralelo_user as tbPU', 'tbPU.user_id','=','tbU.id')
                ->join('paralelos as tbP', 'tbP.id','=','tbPU.paralelo_id')
                ->join('nivels as tbNi', 'tbNi.id','=','tbP.idNivel')
                ->join('role_user as tbRU', 'tbRU.user_id','=','tbU.id')
                ->join('roles as tbR', 'tbR.id','=','tbRU.role_id')
                ->join('asistencia_user as tbAU', 'tbAU.user_id','=','tbU.id')
                ->join('asistencias as tbAs', 'tbAs.id','=','tbAU.asistencia_id')
                     ->select(DB::raw('count(*) as tar_count'))
                     ->whereBetween('tbAs.fechaAsis',[$f1,$f2])
                     // ->where('estado', '<>', 0)
                     // ->groupBy('estado')
                     ->get();
        // dd($cAsis);
        $countA=$cAsis[0]->tar_count;
        $idP=$user[0]->idPR;

        $parall=paralelo::findOrFail($idP);

        $nivel=Nivel::findOrFail($parall->idNivel);
        
        $anio=anio::findOrFail($idP);
        $userC=DB::table('users as tbU')
                ->join('paralelo_user as tbPU', 'tbPU.user_id','=','tbU.id')
                ->join('paralelos as tbP', 'tbP.id','=','tbPU.paralelo_id')
                ->join('nivels as tbNi', 'tbNi.id','=','tbP.idNivel')
                ->join('role_user as tbRU', 'tbRU.user_id','=','tbU.id')
                ->join('roles as tbR', 'tbR.id','=','tbRU.role_id')
                ->select('tbU.id','tbPU.id as idR','tbU.name as nomb','tbU.apellido as apell','tbU.direccion as direcc','tbNi.nombreN as lvl','tbP.nombreP as cP','tbU.telefono as telef','tbU.celular as cel','tbU.email as correo','tbR.descripcion as Rol')
                ->where('tbP.id','LIKE','%'.$parall->id.'%')
                ->get();
                // dd($asisR);
        $valor=$idP;
        if ($request)
        {
            if ($countA>='3') {
                # code...
                return view ('Docente.Asistencia.index',["valor"=>$valor,"asisR"=>$asisR,"user"=>$user,"userC"=>$userC,"parall"=>$parall,"nivel"=>$nivel,"anio"=>$anio]);
            }
            else{
                return view ('errors.402');   
            }
        
            
            
        }
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
